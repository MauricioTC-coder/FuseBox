# FuseBox ID

Identificação automática do modelo/sufixo de Fuse Boxes automotivas a partir de **uma fotografia**,
com **OpenCV puro** (sem IA generativa, sem modelos treinados, sem machine learning).
Toda a configuração é feita na interface web — sem editar código. **Corre só com Python** (sem Docker, Node ou nginx).

## Windows
1. Descompacte a pasta e faça duplo clique em **`iniciar.bat`**.
2. Na 1.ª vez cria sozinho o ambiente (`.venv`) e instala as dependências (alguns minutos, precisa de Internet).
   Se não tiver Python, tenta instalar o Python 3.12 com o winget; se falhar, instale em python.org (marque *Add to PATH*).
3. O browser abre em `http://localhost:8080`. Se o Windows perguntar pela firewall, permita (acesso por outros PCs/tablets).
4. Arranque automático ao iniciar sessão: `iniciar_com_windows.bat`.

## Ubuntu / Debian — duplo clique
1. Descompacte a pasta.
2. Duplo clique em **`Iniciar FuseBox ID.desktop`**. Na 1.ª vez o Ubuntu pede confirmação: clique com o botão direito →
   *Permitir execução* (ou *Allow Launching*) e depois duplo clique de novo.
3. Abre uma janela de terminal (deixe-a aberta; fechá-la pára o sistema), cria sozinho o ambiente, instala as dependências
   (pode pedir a palavra-passe para instalar o `python3-venv`) e abre o browser em `http://localhost:8080`.

Alternativas:
- `bash instalar_atalho.sh` (uma vez) cria um ícone **FuseBox ID** no ambiente de trabalho e no menu de aplicações,
  já confiável: dali em diante é só duplo clique.
- Duplo clique em `iniciar.sh` (escolha *Executar*), ou no terminal: `./iniciar.sh`.
- Serviço (arranca com o servidor): `sudo ./instalar_servico.sh`.

## Configuração inicial (fotos reais)
`config/modelos_iniciais.json` tem cores, tolerâncias (alinhamento por âncoras) e os modelos AC, AK_AT, AM, AQ, AR, AS
(+ AN_AP inativo) construídos a partir das fotografias de referência. Engenharia → Sistema → Importar (marque "Substituir tudo").
Análise completa: `docs/ANALISE_FOTOS.md`.

## Utilização
- Password inicial do Modo Engenharia: `engenharia` (altere em Engenharia → Sistema).
- Porta, password inicial e pasta de dados: ficheiro `.env` (criado no 1.º arranque a partir de `.env.example`).
- Dados (base de dados + imagens): pasta `data/`. **Backup = copiar essa pasta** (ou Engenharia → Sistema → Backup).
- Atualizar: descompacte a nova versão por cima, mantendo `data/` e `.env`; o `iniciar` reinstala o que mudou.
- Parar: Ctrl+C ou fechar a janela (serviço Ubuntu: `sudo systemctl stop fusebox`).

## Desenvolvimento
```bash
python run.py --install-only            # cria .venv
.venv/bin/pip install -r backend/requirements-dev.txt
cd backend && ../.venv/bin/python -m pytest -q tests
cd frontend && npm install && npm run build && rm -rf ../backend/web && cp -r dist ../backend/web   # recompilar a UI
```

## Estrutura
```
run.py · iniciar.bat/.sh · instalar_servico.sh · iniciar_com_windows.bat   lançadores
backend/app/   vision.py (OpenCV) · service.py · db.py · auth.py · routers/
backend/web/   interface React já compilada (servida pelo FastAPI)
frontend/src/  código-fonte da interface
docs/          MANUAL_TECNICO.md · MANUAL_UTILIZADOR.md
docker-compose.yml, */Dockerfile   (opcional, não necessário)
```
