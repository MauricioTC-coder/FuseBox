"""FuseBox ID - identificação visual de Fuse Boxes (OpenCV puro, sem ML)."""
