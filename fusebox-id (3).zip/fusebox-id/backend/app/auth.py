"""Autenticação do Modo Engenharia: password PBKDF2 + token assinado (HMAC) com expiração."""
import base64
import hashlib
import hmac
import json
import secrets
import time

from fastapi import Header, HTTPException, Request

from .config import TOKEN_TTL_SECONDS
from .db import get_db

_fails: dict[str, list[float]] = {}  # anti força-bruta (por processo)


def hash_password(pw: str, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 200_000)
    return f"{salt}${dk.hex()}"


def verify_password(pw: str, stored: str) -> bool:
    salt, h = stored.split("$")
    return hmac.compare_digest(hash_password(pw, salt).split("$")[1], h)


def _get(key: str):
    with get_db() as c:
        row = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return json.loads(row["value"]) if row else None


def set_password(new_pw: str):
    with get_db() as c:
        c.execute("UPDATE settings SET value=? WHERE key='_eng_password'", (json.dumps(hash_password(new_pw)),))


def check_password(pw: str) -> bool:
    return verify_password(pw, _get("_eng_password"))


def make_token() -> str:
    body = base64.urlsafe_b64encode(json.dumps({"exp": time.time() + TOKEN_TTL_SECONDS}).encode()).decode()
    sig = hmac.new(_get("_secret_key").encode(), body.encode(), hashlib.sha256).hexdigest()
    return f"{body}.{sig}"


def require_eng(x_eng_token: str | None = Header(default=None)):
    """Dependência FastAPI: exige token válido do Modo Engenharia."""
    try:
        body, sig = (x_eng_token or "").split(".")
        good = hmac.new(_get("_secret_key").encode(), body.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, good):
            raise ValueError
        if json.loads(base64.urlsafe_b64decode(body))["exp"] < time.time():
            raise ValueError
    except Exception:
        raise HTTPException(401, "Sessão de engenharia inválida ou expirada.")


def client_ip(request: Request) -> str:
    fwd = request.headers.get("x-forwarded-for")
    return fwd.split(",")[0].strip() if fwd else (request.client.host if request.client else "?")


def check_rate(ip: str):
    now = time.time()
    _fails[ip] = [t for t in _fails.get(ip, []) if now - t < 300]
    if len(_fails[ip]) >= 5:
        raise HTTPException(429, "Demasiadas tentativas. Aguarde 5 minutos.")


def register_fail(ip: str):
    _fails.setdefault(ip, []).append(time.time())
