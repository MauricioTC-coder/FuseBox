"""Configuração global, lida de variáveis de ambiente."""
import os
from pathlib import Path

DATA_DIR = Path(os.getenv("FUSEBOX_DATA_DIR", "./data")).resolve()
DB_PATH = DATA_DIR / "fusebox.db"
IMG_DIR = DATA_DIR / "images"
# Password inicial do Modo Engenharia (alterável na interface; só usada no 1.º arranque).
DEFAULT_ENG_PASSWORD = os.getenv("FUSEBOX_ENG_PASSWORD", "engenharia")
TOKEN_TTL_SECONDS = int(os.getenv("FUSEBOX_TOKEN_TTL", "3600"))
CORS_ORIGINS = [o.strip() for o in os.getenv("FUSEBOX_CORS", "http://localhost:5173").split(",") if o.strip()]
MAX_UPLOAD_BYTES = int(os.getenv("FUSEBOX_MAX_UPLOAD_MB", "25")) * 1024 * 1024

VERSION = "1.9.0"
