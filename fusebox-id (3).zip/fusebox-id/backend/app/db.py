"""Acesso à base de dados SQLite: ligação, esquema e dados iniciais."""
import json
import sqlite3
from contextlib import contextmanager

from .config import DATA_DIR, DB_PATH, IMG_DIR

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS colors (
    name TEXT PRIMARY KEY, mode TEXT NOT NULL, params TEXT NOT NULL, sort INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS models (
    id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
    description TEXT DEFAULT '', active INTEGER DEFAULT 1, created_at TEXT, min_confidence REAL);
CREATE TABLE IF NOT EXISTS layouts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    model_id INTEGER NOT NULL REFERENCES models(id) ON DELETE CASCADE,
    name TEXT NOT NULL, image_file TEXT, active INTEGER DEFAULT 1, created_at TEXT);
CREATE TABLE IF NOT EXISTS regions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    layout_id INTEGER NOT NULL REFERENCES layouts(id) ON DELETE CASCADE,
    name TEXT NOT NULL, x REAL NOT NULL, y REAL NOT NULL, w REAL NOT NULL, h REAL NOT NULL,
    color TEXT NOT NULL, tolerance REAL DEFAULT 60, ring_margin REAL DEFAULT 0, ring_max REAL DEFAULT 25);
CREATE TABLE IF NOT EXISTS history (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, operator TEXT,
    model_code TEXT, layout_id INTEGER, score REAL, status TEXT NOT NULL,
    image_file TEXT, annotated_file TEXT, details TEXT);
CREATE INDEX IF NOT EXISTS idx_history_ts ON history(ts);
CREATE INDEX IF NOT EXISTS idx_history_model ON history(model_code);
CREATE INDEX IF NOT EXISTS idx_regions_layout ON regions(layout_id);
"""

# Valores por defeito (todos editáveis no ecrã "Tolerâncias").
DEFAULT_SETTINGS = {
    "color_tolerance": 10,       # alargamento das gamas de cor (0-50)
    "position_tolerance": 2,     # deslocamento máx. das regiões, % da largura (0-20)
    "rotation_tolerance": 5,     # graus de rotação testados (0-45)
    "min_confidence": 90,        # confiança mínima para PASS (%)
    "min_margin": 5,             # diferença mínima para o 2.º modelo (pontos %)
    "min_box_area": 10,          # área mínima da Fuse Box na foto (%)
    "canvas_width": 800,         # tamanho da imagem alinhada
    "canvas_height": 600,
    "require_box": False,        # True: sem Fuse Box detetada => FAIL; False: usa a imagem inteira e avisa
    "history_retention_days": 0, # 0 = guardar para sempre
    "align_mode": "box",         # "box" = contorno da caixa; "anchors" = âncoras de cor (recomendado)
    "anchor_color": "RED",       # cor usada como âncora (maior bloco, ex.: os 2 relés vermelhos)
}

# Gamas HSV na escala do OpenCV (H 0-179, S 0-255, V 0-255). Ajustáveis na interface.
DEFAULT_COLORS = [
    ("BLUE", "hsv", {"h_min": 100, "h_max": 130, "s_min": 100, "s_max": 255, "v_min": 50, "v_max": 255}),
    ("RED", "hsv", {"h_min": 170, "h_max": 10, "s_min": 120, "s_max": 255, "v_min": 70, "v_max": 255}),
    ("BROWN", "hsv", {"h_min": 8, "h_max": 22, "s_min": 80, "s_max": 220, "v_min": 30, "v_max": 150}),
    ("GRAY", "hsv", {"h_min": 0, "h_max": 179, "s_min": 0, "s_max": 50, "v_min": 70, "v_max": 200}),
    ("EMPTY", "hsv", {"h_min": 0, "h_max": 179, "s_min": 0, "s_max": 255, "v_min": 0, "v_max": 45}),
]


@contextmanager
def get_db():
    """Ligação SQLite com commit/rollback automático."""
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    """Cria pastas, esquema e dados iniciais (idempotente)."""
    from .auth import hash_password  # import local: evita ciclo
    from .config import DEFAULT_ENG_PASSWORD
    import secrets

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    for sub in ("hist", "ref"):
        (IMG_DIR / sub).mkdir(parents=True, exist_ok=True)
    raw = sqlite3.connect(DB_PATH, timeout=30)
    raw.execute("PRAGMA journal_mode=WAL")
    raw.close()
    with get_db() as c:
        c.executescript(SCHEMA)
        if "min_confidence" not in [r["name"] for r in c.execute("PRAGMA table_info(models)")]:
            c.execute("ALTER TABLE models ADD COLUMN min_confidence REAL")  # migração de BDs antigas
        rcols = [r["name"] for r in c.execute("PRAGMA table_info(regions)")]
        if "ring_margin" not in rcols:  # migração de BDs antigas
            c.execute("ALTER TABLE regions ADD COLUMN ring_margin REAL DEFAULT 0")
            c.execute("ALTER TABLE regions ADD COLUMN ring_max REAL DEFAULT 25")
        for k, v in DEFAULT_SETTINGS.items():
            c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, json.dumps(v)))
        for i, (n, mode, p) in enumerate(DEFAULT_COLORS):
            c.execute("INSERT OR IGNORE INTO colors(name,mode,params,sort) VALUES(?,?,?,?)",
                      (n, mode, json.dumps(p), i))
        # Chaves internas (prefixo "_"), nunca expostas nem exportadas.
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('_secret_key',?)",
                  (json.dumps(secrets.token_hex(32)),))
        if not c.execute("SELECT 1 FROM settings WHERE key='_migr_require_box'").fetchone():
            c.execute("UPDATE settings SET value='false' WHERE key='require_box'")  # migração única
            c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('_migr_require_box','true')")
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('_eng_password',?)",
                  (json.dumps(hash_password(DEFAULT_ENG_PASSWORD)),))
