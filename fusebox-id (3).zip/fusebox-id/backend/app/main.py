"""Aplicação FastAPI - FuseBox ID."""
import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

from . import service
from .config import CORS_ORIGINS
from .db import get_db, init_db
from .routers import engineering, public


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    with get_db() as c:  # retenção automática do histórico (se configurada)
        service.purge_history(c, int(service.get_settings(c)["history_retention_days"]))
    yield


app = FastAPI(title="FuseBox ID", version="1.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=CORS_ORIGINS, allow_methods=["*"], allow_headers=["*"])
app.include_router(public.router, prefix="/api")
app.include_router(engineering.router, prefix="/api")


# Interface web já compilada (backend/web). Sem Node/nginx: o próprio FastAPI serve a aplicação.
WEB_DIR = Path(os.getenv("FUSEBOX_WEB_DIR", Path(__file__).resolve().parent.parent / "web"))
if (WEB_DIR / "index.html").exists():
    if (WEB_DIR / "assets").exists():
        app.mount("/assets", StaticFiles(directory=WEB_DIR / "assets"), name="assets")

    @app.get("/{path:path}", include_in_schema=False)
    def spa(path: str):
        if path.startswith("api/"):
            raise HTTPException(404, "Não encontrado.")
        f = (WEB_DIR / path).resolve()
        if path and f.is_file() and WEB_DIR.resolve() in f.parents:
            return FileResponse(f)
        return FileResponse(WEB_DIR / "index.html")  # rotas do React (/historico, /engenharia, ...)
