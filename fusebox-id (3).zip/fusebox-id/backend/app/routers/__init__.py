"""Routers da API (public = operação, engineering = Modo Engenharia)."""
