"""Endpoints do Modo Engenharia (exigem token): modelos, layouts, regiões, cores, tolerâncias, backup."""
import json
import os
import sqlite3
import tempfile
import zipfile

from fastapi import APIRouter, Body, Depends, File, Form, HTTPException, Response, UploadFile
from fastapi.responses import FileResponse
from starlette.background import BackgroundTask
from starlette.concurrency import run_in_threadpool

from .. import auth, service, vision
from ..config import DATA_DIR, DB_PATH, IMG_DIR, MAX_UPLOAD_BYTES
from ..db import get_db
from ..schemas import ColorIn, LayoutUpdate, ModelIn, PasswordIn, PurgeIn, RegionsIn

router = APIRouter(dependencies=[Depends(auth.require_eng)])


async def _img(f: UploadFile):
    data = await f.read(MAX_UPLOAD_BYTES + 1)
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(413, "Imagem demasiado grande.")
    try:
        return vision.limit_size(vision.decode_image(data))
    except ValueError as e:
        raise HTTPException(422, str(e))


# ---------------------------------------------------------------- autenticação
@router.get("/auth/check")
def check():
    return {"ok": True}


@router.post("/auth/password")
def change_password(body: PasswordIn):
    if not auth.check_password(body.old_password):
        raise HTTPException(403, "Password atual incorreta.")
    auth.set_password(body.new_password)
    return {"ok": True}


# ---------------------------------------------------------------------- modelos
@router.post("/models", status_code=201)
def create_model(body: ModelIn):
    with get_db() as c:
        try:
            mid = c.execute("INSERT INTO models(code,name,description,active,created_at,min_confidence) VALUES(?,?,?,?,?,?)",
                            (body.code, body.name, body.description, int(body.active), service.now_str(),
                             body.min_confidence)).lastrowid
        except sqlite3.IntegrityError:
            raise HTTPException(409, "Já existe um modelo com esse código.")
    return {"id": mid}


@router.put("/models/{mid}")
def update_model(mid: int, body: ModelIn):
    with get_db() as c:
        try:
            n = c.execute("UPDATE models SET code=?,name=?,description=?,active=?,min_confidence=? WHERE id=?",
                          (body.code, body.name, body.description, int(body.active), body.min_confidence, mid)).rowcount
        except sqlite3.IntegrityError:
            raise HTTPException(409, "Já existe um modelo com esse código.")
    if not n:
        raise HTTPException(404, "Modelo não encontrado.")
    return {"ok": True}


@router.delete("/models/{mid}", status_code=204)
def delete_model(mid: int):
    with get_db() as c:
        service.delete_model(c, mid)


# ---------------------------------------------------------------------- layouts
@router.post("/models/{mid}/layouts", status_code=201)
async def add_layout(mid: int, name: str = Form(...), image: UploadFile = File(...), auto_crop: bool = Form(True)):
    img = await _img(image)

    def work():
        with get_db() as c:
            if not c.execute("SELECT 1 FROM models WHERE id=?", (mid,)).fetchone():
                raise HTTPException(404, "Modelo não encontrado.")
            canvas, found = vision.prepare_reference(img, service.get_settings(c), auto_crop, service.get_colors(c))
            rel = service.save_jpeg(canvas, "ref", 92)
            lid = c.execute("INSERT INTO layouts(model_id,name,image_file,active,created_at) VALUES(?,?,?,1,?)",
                            (mid, name.strip()[:80] or "Layout", rel, service.now_str())).lastrowid
            return {"id": lid, "box_found": found}
    return await run_in_threadpool(work)


@router.post("/layouts/{lid}/image")
async def replace_layout_image(lid: int, image: UploadFile = File(...), auto_crop: bool = Form(True)):
    img = await _img(image)

    def work():
        with get_db() as c:
            row = c.execute("SELECT image_file FROM layouts WHERE id=?", (lid,)).fetchone()
            if not row:
                raise HTTPException(404, "Layout não encontrado.")
            canvas, found = vision.prepare_reference(img, service.get_settings(c), auto_crop, service.get_colors(c))
            rel = service.save_jpeg(canvas, "ref", 92)
            c.execute("UPDATE layouts SET image_file=? WHERE id=?", (rel, lid))
            service.remove_file(row["image_file"])
            return {"box_found": found}
    return await run_in_threadpool(work)


@router.put("/layouts/{lid}")
def update_layout(lid: int, body: LayoutUpdate):
    with get_db() as c:
        n = c.execute("UPDATE layouts SET name=?, active=? WHERE id=?", (body.name, int(body.active), lid)).rowcount
    if not n:
        raise HTTPException(404, "Layout não encontrado.")
    return {"ok": True}


@router.delete("/layouts/{lid}", status_code=204)
def delete_layout(lid: int):
    with get_db() as c:
        row = c.execute("SELECT image_file FROM layouts WHERE id=?", (lid,)).fetchone()
        c.execute("DELETE FROM layouts WHERE id=?", (lid,))
        if row:
            service.remove_file(row["image_file"])


@router.put("/layouts/{lid}/regions")
def save_regions(lid: int, body: RegionsIn):
    with get_db() as c:
        if not c.execute("SELECT 1 FROM layouts WHERE id=?", (lid,)).fetchone():
            raise HTTPException(404, "Layout não encontrado.")
        service.replace_regions(c, lid, [r.model_dump() for r in body.regions])
    return {"ok": True, "count": len(body.regions)}


# ------------------------------------------------------------------------ cores
@router.put("/colors/{name}")
def save_color(name: str, body: ColorIn):
    name = name.strip().upper()
    if not name or len(name) > 30 or not name.replace("_", "").isalnum():
        raise HTTPException(422, "Nome de cor inválido (use letras, números e _).")
    p = service.validate_color(body.mode, body.params)
    with get_db() as c:
        nxt = c.execute("SELECT COALESCE(MAX(sort),0)+1 FROM colors").fetchone()[0]
        c.execute("INSERT INTO colors(name,mode,params,sort) VALUES(?,?,?,?) ON CONFLICT(name) DO UPDATE SET "
                  "mode=excluded.mode, params=excluded.params", (name, body.mode, json.dumps(p), nxt))
    return {"ok": True}


@router.delete("/colors/{name}", status_code=204)
def delete_color(name: str):
    with get_db() as c:
        used = c.execute("SELECT COUNT(*) FROM regions WHERE color=?", (name,)).fetchone()[0]
        if used:
            raise HTTPException(409, f"Cor em uso por {used} região(ões).")
        c.execute("DELETE FROM colors WHERE name=?", (name,))


@router.post("/colors/preview")
async def color_preview(image: UploadFile = File(...), config: str = Form(...), tolerance: float = Form(0)):
    img = await _img(image)
    try:
        cfg = json.loads(config)
        cfg = {"mode": cfg["mode"], "params": service.validate_color(cfg["mode"], cfg["params"])}
    except (ValueError, KeyError):
        raise HTTPException(422, "Configuração de cor inválida.")
    out = await run_in_threadpool(vision.color_preview, img, cfg, max(0.0, min(50.0, tolerance)))
    return Response(vision.encode_jpeg(out, 80), media_type="image/jpeg")


# ------------------------------------------------------------------ tolerâncias
@router.put("/settings")
def save_settings(values: dict = Body(...)):
    with get_db() as c:
        service.save_settings(c, values)
        return service.get_settings(c)


# ------------------------------------------------------ import / export / backup
@router.get("/config/export")
def export_config():
    with get_db() as c:
        data = service.export_config(c)
    return Response(json.dumps(data), media_type="application/json",
                    headers={"Content-Disposition": 'attachment; filename="fusebox-config.json"'})


@router.post("/config/import")
def import_config(payload: dict = Body(...), replace: bool = False):
    with get_db() as c:
        return service.import_config(c, payload, replace)


@router.get("/backup")
def backup():
    """ZIP com cópia consistente da BD + todas as imagens."""
    tmp_db = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    tmp_db.close()
    src = sqlite3.connect(DB_PATH)
    dst = sqlite3.connect(tmp_db.name)
    src.backup(dst)
    src.close(), dst.close()
    tmp_zip = tempfile.NamedTemporaryFile(suffix=".zip", delete=False)
    tmp_zip.close()
    with zipfile.ZipFile(tmp_zip.name, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(tmp_db.name, "fusebox.db")
        for p in IMG_DIR.rglob("*.jpg"):
            z.write(p, f"images/{p.relative_to(IMG_DIR)}")
    os.unlink(tmp_db.name)
    return FileResponse(tmp_zip.name, media_type="application/zip", filename="fusebox-backup.zip",
                        background=BackgroundTask(os.unlink, tmp_zip.name))


@router.post("/history/purge")
def purge(body: PurgeIn):
    with get_db() as c:
        return {"deleted": service.purge_history(c, body.days)}
