"""Endpoints de operação (sem password): identificar, histórico, dashboard, leitura de configuração."""
from fastapi import APIRouter, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse

from .. import auth, service
from ..config import IMG_DIR, MAX_UPLOAD_BYTES, VERSION
from ..db import get_db
from ..schemas import LoginIn

router = APIRouter()


async def _read_upload(f: UploadFile) -> bytes:
    data = await f.read(MAX_UPLOAD_BYTES + 1)
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(413, "Imagem demasiado grande.")
    return data


@router.get("/health")
def health():
    with get_db() as c:
        c.execute("SELECT 1")
    return {"status": "ok", "version": VERSION}


@router.post("/auth/login")
def login(body: LoginIn, request: Request):
    ip = auth.client_ip(request)
    auth.check_rate(ip)
    if not auth.check_password(body.password):
        auth.register_fail(ip)
        raise HTTPException(401, "Password incorreta.")
    return {"token": auth.make_token()}


@router.get("/models")
def models():
    with get_db() as c:
        return service.list_models(c)


@router.get("/layouts/{layout_id}")
def layout(layout_id: int):
    with get_db() as c:
        return service.get_layout(c, layout_id)


@router.get("/layouts/{layout_id}/image")
def layout_image(layout_id: int):
    with get_db() as c:
        row = c.execute("SELECT image_file FROM layouts WHERE id=?", (layout_id,)).fetchone()
    if not row or not row["image_file"] or not (IMG_DIR / row["image_file"]).exists():
        raise HTTPException(404, "Sem imagem de referência.")
    return FileResponse(IMG_DIR / row["image_file"], media_type="image/jpeg", headers={"Cache-Control": "no-cache"})


@router.get("/colors")
def colors():
    with get_db() as c:
        return service.get_colors(c)


@router.get("/settings")
def settings():
    with get_db() as c:
        return service.get_settings(c)


@router.post("/identify")
async def identify(image: UploadFile = File(...), operator: str = Form("N/A"), dry_run: bool = Form(False)):
    data = await _read_upload(image)
    op = operator.strip()[:60] or "N/A"
    from starlette.concurrency import run_in_threadpool

    def work():
        with get_db() as c:
            return service.identify_and_log(c, data, op, dry_run)
    return await run_in_threadpool(work)  # OpenCV é CPU-bound: fora do event loop


@router.get("/history")
def history(q: str = "", status: str = "", date_from: str = "", date_to: str = "",
            limit: int = Query(25, ge=1, le=200), offset: int = Query(0, ge=0)):
    with get_db() as c:
        return service.search_history(c, q.strip(), status, date_from, date_to, limit, offset)


@router.get("/history/{hid}")
def history_item(hid: int):
    import json
    with get_db() as c:
        r = c.execute("SELECT * FROM history WHERE id=?", (hid,)).fetchone()
    if not r:
        raise HTTPException(404, "Registo não encontrado.")
    d = dict(r)
    d["details"] = json.loads(d["details"] or "{}")
    d.pop("image_file"), d.pop("annotated_file")
    return d


def _hist_file(hid: int, col: str):
    with get_db() as c:
        r = c.execute(f"SELECT {col} f FROM history WHERE id=?", (hid,)).fetchone()
    if not r or not r["f"] or not (IMG_DIR / r["f"]).exists():
        raise HTTPException(404, "Imagem não encontrada.")
    return FileResponse(IMG_DIR / r["f"], media_type="image/jpeg")


@router.get("/history/{hid}/image")
def history_image(hid: int):
    return _hist_file(hid, "image_file")


@router.get("/history/{hid}/annotated")
def history_annotated(hid: int):
    return _hist_file(hid, "annotated_file")


@router.get("/dashboard")
def dashboard(days: int = Query(7, ge=1, le=365)):
    with get_db() as c:
        return service.dashboard(c, days)
