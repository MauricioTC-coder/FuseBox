"""Esquemas de validação (Pydantic) dos pedidos da API."""
from typing import Literal

from pydantic import BaseModel, Field


class LoginIn(BaseModel):
    password: str = Field(min_length=1, max_length=200)


class PasswordIn(BaseModel):
    old_password: str
    new_password: str = Field(min_length=6, max_length=200)


class ModelIn(BaseModel):
    code: str = Field(min_length=1, max_length=40, pattern=r"^[A-Za-z0-9_\-]+$")
    name: str = Field(min_length=1, max_length=120)
    description: str = Field(default="", max_length=500)
    active: bool = True
    min_confidence: float | None = Field(default=None, ge=0, le=100)  # None = usar a global


class LayoutUpdate(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    active: bool = True


class RegionIn(BaseModel):
    name: str = Field(min_length=1, max_length=40)
    x: float = Field(ge=0, le=1)
    y: float = Field(ge=0, le=1)
    w: float = Field(gt=0, le=1)
    h: float = Field(gt=0, le=1)
    color: str = Field(min_length=1, max_length=40)
    tolerance: float = Field(default=60, ge=1, le=100)
    ring_margin: float = Field(default=0, ge=0, le=200)   # 0 = sem verificação de contorno
    ring_max: float = Field(default=25, ge=0, le=100)


class RegionsIn(BaseModel):
    regions: list[RegionIn] = Field(max_length=300)


class ColorIn(BaseModel):
    mode: Literal["hsv", "rgb"]
    params: dict


class PurgeIn(BaseModel):
    days: int = Field(ge=1, le=3650)
