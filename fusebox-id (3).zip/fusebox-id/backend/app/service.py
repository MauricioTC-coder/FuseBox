"""Regras de negócio: configurações, cores, modelos, histórico, import/export."""
from __future__ import annotations

import base64
import json
import uuid
from datetime import date, datetime, timedelta

from fastapi import HTTPException

from . import vision
from .config import IMG_DIR
from .db import DEFAULT_SETTINGS

LIMITS = {"color_tolerance": (0, 50), "position_tolerance": (0, 20), "rotation_tolerance": (0, 45),
          "min_confidence": (0, 100), "min_margin": (0, 100), "min_box_area": (1, 90),
          "canvas_width": (320, 2000), "canvas_height": (240, 2000), "history_retention_days": (0, 3650)}
INT_KEYS = {"canvas_width", "canvas_height", "history_retention_days"}


def now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ------------------------------------------------------------------ definições
def get_settings(conn) -> dict:
    rows = {r["key"]: json.loads(r["value"]) for r in conn.execute("SELECT key,value FROM settings")}
    return {k: rows.get(k, v) for k, v in DEFAULT_SETTINGS.items()}


def save_settings(conn, new: dict):
    for k, v in new.items():
        if k not in DEFAULT_SETTINGS:
            continue
        if k in ("align_mode", "anchor_color"):
            if k == "align_mode" and v not in ("box", "anchors"):
                raise HTTPException(422, "Método de alinhamento inválido.")
            if k == "anchor_color" and v not in {c["name"] for c in get_colors(conn)}:
                raise HTTPException(422, "Cor de âncora desconhecida.")
            conn.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, json.dumps(v)))
            continue
        if k == "require_box":
            v = bool(v)
        else:
            lo, hi = LIMITS[k]
            try:
                v = max(lo, min(hi, float(v)))
            except (TypeError, ValueError):
                raise HTTPException(422, f"Valor inválido para {k}.")
            v = int(v) if k in INT_KEYS else round(v, 2)
        conn.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                     (k, json.dumps(v)))


# ----------------------------------------------------------------------- cores
def get_colors(conn) -> list[dict]:
    return [{"name": r["name"], "mode": r["mode"], "params": json.loads(r["params"])}
            for r in conn.execute("SELECT * FROM colors ORDER BY sort, name")]


def validate_color(mode: str, p: dict) -> dict:
    try:
        if mode == "hsv":
            q = {"h_min": (0, 179), "h_max": (0, 179), "s_min": (0, 255), "s_max": (0, 255),
                 "v_min": (0, 255), "v_max": (0, 255)}
        elif mode == "rgb":
            q = {"r": (0, 255), "g": (0, 255), "b": (0, 255), "distance": (0, 442)}
        else:
            raise ValueError
        out = {}
        for k, (lo, hi) in q.items():
            out[k] = max(lo, min(hi, float(p[k])))
        if mode == "hsv" and all(p.get(k) is not None for k in ("c_h", "c_s", "c_v")):  # centro medido (opcional)
            out.update(c_h=max(0.0, min(179.0, float(p["c_h"]))), c_s=max(0.0, min(255.0, float(p["c_s"]))),
                       c_v=max(0.0, min(255.0, float(p["c_v"]))))
        return out
    except Exception:
        raise HTTPException(422, "Parâmetros de cor inválidos.")


# ---------------------------------------------------------------------- imagens
def save_jpeg(img, sub: str, quality: int = 88) -> str:
    rel = f"{sub}/{uuid.uuid4().hex}.jpg"
    (IMG_DIR / rel).write_bytes(vision.encode_jpeg(img, quality))
    return rel


def remove_file(rel: str | None):
    if rel:
        try:
            (IMG_DIR / rel).unlink(missing_ok=True)
        except OSError:
            pass


# ---------------------------------------------------------------------- modelos
def list_models(conn) -> list[dict]:
    out = []
    for m in conn.execute("SELECT * FROM models ORDER BY code"):
        lays = [dict(id=l["id"], name=l["name"], active=bool(l["active"]), region_count=l["n"])
                for l in conn.execute(
                    "SELECT l.*, (SELECT COUNT(*) FROM regions r WHERE r.layout_id=l.id) n "
                    "FROM layouts l WHERE model_id=? ORDER BY l.id", (m["id"],))]
        out.append({"id": m["id"], "code": m["code"], "name": m["name"], "description": m["description"],
                    "active": bool(m["active"]), "min_confidence": m["min_confidence"], "layouts": lays})
    return out


def get_layout(conn, layout_id: int) -> dict:
    l = conn.execute("SELECT l.*, m.code mcode, m.name mname FROM layouts l JOIN models m ON m.id=l.model_id "
                     "WHERE l.id=?", (layout_id,)).fetchone()
    if not l:
        raise HTTPException(404, "Layout não encontrado.")
    regs = [dict(name=r["name"], x=r["x"], y=r["y"], w=r["w"], h=r["h"], color=r["color"], tolerance=r["tolerance"],
                 ring_margin=r["ring_margin"] or 0, ring_max=25 if r["ring_max"] is None else r["ring_max"])
            for r in conn.execute("SELECT * FROM regions WHERE layout_id=? ORDER BY id", (layout_id,))]
    return {"id": l["id"], "model_id": l["model_id"], "model_code": l["mcode"], "model_name": l["mname"],
            "name": l["name"], "active": bool(l["active"]), "has_image": bool(l["image_file"]), "regions": regs}


def load_layouts(conn) -> list[dict]:
    """Layouts ativos (de modelos ativos) com pelo menos uma região."""
    out = []
    for l in conn.execute("SELECT l.id, l.name, m.code, m.name mname, m.min_confidence mconf FROM layouts l JOIN models m ON m.id=l.model_id "
                          "WHERE l.active=1 AND m.active=1"):
        regs = [dict(r) for r in conn.execute(
            "SELECT name,x,y,w,h,color,tolerance,ring_margin,ring_max FROM regions WHERE layout_id=? ORDER BY id", (l["id"],))]
        if regs:
            out.append({"id": l["id"], "name": l["name"], "model_code": l["code"], "model_name": l["mname"],
                        "min_confidence": l["mconf"], "regions": regs})
    return out


def delete_model(conn, model_id: int):
    for l in conn.execute("SELECT image_file FROM layouts WHERE model_id=?", (model_id,)):
        remove_file(l["image_file"])
    conn.execute("DELETE FROM models WHERE id=?", (model_id,))


def replace_regions(conn, layout_id: int, regions: list[dict]):
    names = {c["name"] for c in get_colors(conn)}
    seen = set()
    for r in regions:
        if r["color"] not in names:
            raise HTTPException(422, f'Cor desconhecida: {r["color"]}')
        if r["name"] in seen:
            raise HTTPException(422, f'Nome de região duplicado: {r["name"]}')
        seen.add(r["name"])
    conn.execute("DELETE FROM regions WHERE layout_id=?", (layout_id,))
    conn.executemany("INSERT INTO regions(layout_id,name,x,y,w,h,color,tolerance,ring_margin,ring_max) VALUES(?,?,?,?,?,?,?,?,?,?)",
                     [(layout_id, r["name"], r["x"], r["y"], r["w"], r["h"], r["color"], r["tolerance"],
                       r.get("ring_margin", 0), r.get("ring_max", 25))
                      for r in regions])


# --------------------------------------------------------------- identificação
def identify_and_log(conn, data: bytes, operator: str, dry_run: bool) -> dict:
    try:
        img = vision.limit_size(vision.decode_image(data))
    except ValueError as e:
        raise HTTPException(422, str(e))
    layouts = load_layouts(conn)
    if not layouts:
        raise HTTPException(409, "Nenhum modelo com regiões configurado. Use o Modo Engenharia.")
    res = vision.run_identification(img, layouts, get_colors(conn), get_settings(conn))
    annotated = res.pop("annotated")
    if dry_run:
        res.update(id=None, annotated_b64=base64.b64encode(vision.encode_jpeg(annotated)).decode())
        return res
    ts = now_str()
    detail = {k: res[k] for k in ("regions", "ranking", "reasons", "warnings", "margin", "box_found", "layout")}
    lay_id = next((l["id"] for l in layouts if l["name"] == res["layout"] and l["model_code"] == res["model_code"]), None)
    cur = conn.execute(
        "INSERT INTO history(ts,operator,model_code,layout_id,score,status,image_file,annotated_file,details) "
        "VALUES(?,?,?,?,?,?,?,?,?)",
        (ts, operator, res["model_code"], lay_id, res["confidence"], res["status"],
         save_jpeg(img, "hist", 85), save_jpeg(annotated, "hist", 85), json.dumps(detail)))
    res.update(id=cur.lastrowid, timestamp=ts, operator=operator)
    return res


# -------------------------------------------------------------------- histórico
def search_history(conn, q, status, date_from, date_to, limit, offset) -> dict:
    where, args = [], []
    if q:
        where.append("(model_code LIKE ? OR operator LIKE ?)")
        args += [f"%{q}%"] * 2
    if status in ("PASS", "FAIL"):
        where.append("status=?")
        args.append(status)
    try:
        if date_from:
            where.append("ts >= ?")
            args.append(date.fromisoformat(date_from).isoformat())
        if date_to:
            where.append("ts < ?")
            args.append((date.fromisoformat(date_to) + timedelta(days=1)).isoformat())
    except ValueError:
        raise HTTPException(422, "Data inválida (use AAAA-MM-DD).")
    w = ("WHERE " + " AND ".join(where)) if where else ""
    total = conn.execute(f"SELECT COUNT(*) FROM history {w}", args).fetchone()[0]
    rows = conn.execute(f"SELECT id,ts,operator,model_code,score,status FROM history {w} "
                        "ORDER BY id DESC LIMIT ? OFFSET ?", args + [limit, offset]).fetchall()
    return {"total": total, "items": [dict(r) for r in rows]}


def purge_history(conn, days: int) -> int:
    if days <= 0:
        return 0
    cutoff = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    rows = conn.execute("SELECT image_file,annotated_file FROM history WHERE ts < ?", (cutoff,)).fetchall()
    for r in rows:
        remove_file(r["image_file"])
        remove_file(r["annotated_file"])
    conn.execute("DELETE FROM history WHERE ts < ?", (cutoff,))
    return len(rows)


def dashboard(conn, days: int) -> dict:
    today = date.today().isoformat()
    since = (date.today() - timedelta(days=days - 1)).isoformat()
    t = conn.execute("SELECT COUNT(*) n, COALESCE(SUM(status='PASS'),0) p FROM history WHERE ts >= ?", (today,)).fetchone()
    freq = [dict(r) for r in conn.execute(
        "SELECT model_code, COUNT(*) n FROM history WHERE ts >= ? AND status='PASS' "
        "GROUP BY model_code ORDER BY n DESC LIMIT 12", (since,))]
    daily = [dict(r) for r in conn.execute(
        "SELECT substr(ts,1,10) day, COUNT(*) total, COALESCE(SUM(status='PASS'),0) pass FROM history "
        "WHERE ts >= ? GROUP BY day ORDER BY day", (since,))]
    hourly = [dict(r) for r in conn.execute(
        "SELECT substr(ts,12,2) hour, COUNT(*) total FROM history WHERE ts >= ? GROUP BY hour ORDER BY hour", (today,))]
    return {"today": {"total": t["n"], "pass": t["p"], "fail": t["n"] - t["p"],
                      "pass_rate": round(100 * t["p"] / t["n"], 1) if t["n"] else None},
            "frequency": freq, "daily": daily, "hourly": hourly, "days": days}


# --------------------------------------------------------------- import/export
def export_config(conn) -> dict:
    models = []
    for m in conn.execute("SELECT * FROM models ORDER BY code"):
        lays = []
        for l in conn.execute("SELECT * FROM layouts WHERE model_id=? ORDER BY id", (m["id"],)):
            b64 = None
            if l["image_file"] and (IMG_DIR / l["image_file"]).exists():
                b64 = base64.b64encode((IMG_DIR / l["image_file"]).read_bytes()).decode()
            lays.append({"name": l["name"], "active": bool(l["active"]), "image_b64": b64,
                         "regions": get_layout(conn, l["id"])["regions"]})
        models.append({"code": m["code"], "name": m["name"], "description": m["description"],
                       "active": bool(m["active"]), "min_confidence": m["min_confidence"], "layouts": lays})
    return {"format": "fusebox-config", "version": 1, "exported_at": now_str(),
            "settings": get_settings(conn), "colors": get_colors(conn), "models": models}


def import_config(conn, data: dict, replace: bool) -> dict:
    if data.get("format") != "fusebox-config":
        raise HTTPException(422, "Ficheiro de configuração inválido.")
    if replace:
        for m in conn.execute("SELECT id FROM models").fetchall():
            delete_model(conn, m["id"])
        conn.execute("DELETE FROM colors")
    for i, c in enumerate(data.get("colors", [])):
        p = validate_color(c["mode"], c["params"])
        conn.execute("INSERT INTO colors(name,mode,params,sort) VALUES(?,?,?,?) ON CONFLICT(name) DO UPDATE SET "
                     "mode=excluded.mode, params=excluded.params", (c["name"].upper(), c["mode"], json.dumps(p), i))
    save_settings(conn, data.get("settings", {}))
    n_models = 0
    for m in data.get("models", []):
        old = conn.execute("SELECT id FROM models WHERE code=?", (m["code"],)).fetchone()
        if old:
            delete_model(conn, old["id"])
        mid = conn.execute("INSERT INTO models(code,name,description,active,created_at,min_confidence) VALUES(?,?,?,?,?,?)",
                           (m["code"], m["name"], m.get("description", ""), int(m.get("active", True)), now_str(),
                            m.get("min_confidence"))).lastrowid
        for l in m.get("layouts", []):
            rel = None
            if l.get("image_b64"):
                rel = f"ref/{uuid.uuid4().hex}.jpg"
                (IMG_DIR / rel).write_bytes(base64.b64decode(l["image_b64"]))
            lid = conn.execute("INSERT INTO layouts(model_id,name,image_file,active,created_at) VALUES(?,?,?,?,?)",
                               (mid, l["name"], rel, int(l.get("active", True)), now_str())).lastrowid
            replace_regions(conn, lid, l.get("regions", []))
        n_models += 1
    return {"models": n_models, "colors": len(data.get("colors", []))}
