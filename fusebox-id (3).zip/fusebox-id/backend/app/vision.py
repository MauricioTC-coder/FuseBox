"""
Motor de visão computacional - OpenCV puro (sem IA/ML).

Pipeline:
  1. detect_box        : localiza a Fuse Box (contornos + retângulo de área mínima)
  2. warp_to_canvas    : endireita a perspetiva para uma imagem canónica (ex.: 800x600)
  3. build_candidates  : gera variantes rodadas (tolerância de rotação + 180°)
  4. evaluate_layout   : lê a cor de cada região (HSV/RGB), com tolerância de posição
  5. run_identification: compara com todos os layouts, calcula score e decide PASS/FAIL
"""
from __future__ import annotations

import cv2
import numpy as np


# ----------------------------------------------------------------- utilitários
def decode_image(data: bytes) -> np.ndarray:
    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)  # respeita EXIF
    if img is None:
        raise ValueError("Ficheiro não é uma imagem válida.")
    return img


def encode_jpeg(img: np.ndarray, quality: int = 88) -> bytes:
    ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, quality])
    if not ok:
        raise ValueError("Falha ao codificar imagem.")
    return buf.tobytes()


def limit_size(img: np.ndarray, max_side: int = 1920) -> np.ndarray:
    h, w = img.shape[:2]
    s = max_side / max(h, w)
    return cv2.resize(img, None, fx=s, fy=s, interpolation=cv2.INTER_AREA) if s < 1 else img


# ------------------------------------------------------------ deteção + warp
def order_points(pts: np.ndarray) -> np.ndarray:
    """Ordena 4 pontos: topo-esq, topo-dir, baixo-dir, baixo-esq."""
    pts = pts.reshape(4, 2).astype("float32")
    s, d = pts.sum(axis=1), np.diff(pts, axis=1).ravel()
    return np.array([pts[np.argmin(s)], pts[np.argmin(d)], pts[np.argmax(s)], pts[np.argmax(d)]], "float32")


def detect_box(img: np.ndarray, min_area_pct: float):
    """Devolve os 4 cantos (coords. da imagem original) da Fuse Box, ou None."""
    h, w = img.shape[:2]
    scale = 800 / max(h, w) if max(h, w) > 800 else 1.0
    small = cv2.resize(img, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA) if scale != 1 else img
    gray = cv2.GaussianBlur(cv2.cvtColor(small, cv2.COLOR_BGR2GRAY), (5, 5), 0)
    total = gray.shape[0] * gray.shape[1]

    masks = []
    edges = cv2.dilate(cv2.Canny(gray, 40, 120), np.ones((3, 3), np.uint8), 1)
    masks.append(edges)
    _, otsu = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    masks += [otsu, cv2.bitwise_not(otsu)]

    best, best_area = None, 0.0
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (15, 15))
    for m in masks:
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, kernel)
        cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for c in cnts:
            a = cv2.contourArea(c)
            if a < total * min_area_pct / 100 or a > total * 0.98:
                continue
            rect = cv2.minAreaRect(c)
            ra = rect[1][0] * rect[1][1]
            if ra <= 0 or a / ra < 0.6:  # contorno muito "irregular" para ser uma caixa
                continue
            if a > best_area:
                best_area, best = a, cv2.boxPoints(rect)
    return None if best is None else (best / scale).astype("float32")


def warp_to_canvas(img: np.ndarray, quad, cw: int, ch: int) -> np.ndarray:
    """Endireita a caixa para cw x ch (lado maior na horizontal). Sem quad: redimensiona."""
    if quad is None:
        return cv2.resize(img, (cw, ch), interpolation=cv2.INTER_AREA)
    q = order_points(quad)
    wd = max(np.linalg.norm(q[1] - q[0]), np.linalg.norm(q[2] - q[3]))
    ht = max(np.linalg.norm(q[3] - q[0]), np.linalg.norm(q[2] - q[1]))
    if ht > wd:
        q = np.roll(q, -1, axis=0)
    dst = np.array([[0, 0], [cw - 1, 0], [cw - 1, ch - 1], [0, ch - 1]], "float32")
    M = cv2.getPerspectiveTransform(q, dst)
    return cv2.warpPerspective(img, M, (cw, ch), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)


# Alinhamento por âncoras de cor: o maior bloco da cor-âncora (ex.: os 2 relés vermelhos grandes, comuns a todos
# os modelos) define posição, escala e inclinação. Fixa a Fuse Box na mesma posição/tamanho em qualquer fotografia.
ANCHOR_CANVAS = (600, 800)       # largura x altura (portrait)
ANCHOR_CENTER = (470.0, 460.0)   # onde fica o centro da âncora na imagem alinhada
ANCHOR_WIDTH = 100.0             # largura (px) que a âncora passa a ter


def find_anchor(img: np.ndarray, colors: list[dict], color_name: str, tol: float):
    """Maior bloco da cor-âncora: {cx, cy, width, phi} nas coordenadas de `img`; None se não existir."""
    cfg = next((c for c in colors if c["name"] == color_name), None)
    if cfg is None:
        return None
    h, w = img.shape[:2]
    s0 = 900 / max(h, w) if max(h, w) > 900 else 1.0
    small = cv2.resize(img, None, fx=s0, fy=s0, interpolation=cv2.INTER_AREA) if s0 != 1 else img
    m = color_mask(cv2.cvtColor(small, cv2.COLOR_BGR2HSV), cv2.cvtColor(small, cv2.COLOR_BGR2RGB), cfg, tol)
    m = m.astype(np.uint8) * 255
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (9, 25)))  # junta relés empilhados
    n, lab, st, _ = cv2.connectedComponentsWithStats(m)
    if n < 2:
        return None
    i = 1 + int(np.argmax(st[1:, 4]))
    if st[i, 4] < 0.004 * small.shape[0] * small.shape[1]:
        return None
    cnts, _ = cv2.findContours((lab == i).astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    (cx, cy), (rw, rh), ang = cv2.minAreaRect(max(cnts, key=cv2.contourArea))
    long_a = ang if rw >= rh else ang + 90.0
    phi = ((long_a - 90.0 + 90.0) % 180.0) - 90.0  # inclinação do eixo longo face à vertical
    if max(rw, rh) / max(1.0, min(rw, rh)) < 1.25 or abs(phi) > 45:
        phi = 0.0
    return {"cx": cx / s0, "cy": cy / s0, "width": min(rw, rh) / s0, "phi": phi}


def warp_by_anchor(img: np.ndarray, a: dict):
    """Devolve (imagem alinhada 600x800, máscara de pixéis válidos). Fora da foto = inválido."""
    k = ANCHOR_WIDTH / a["width"]
    M = cv2.getRotationMatrix2D((a["cx"], a["cy"]), a["phi"], k)
    M[:, 2] += (ANCHOR_CENTER[0] - a["cx"], ANCHOR_CENTER[1] - a["cy"])
    flag = cv2.INTER_AREA if k < 1 else cv2.INTER_LINEAR
    canvas = cv2.warpAffine(img, M, ANCHOR_CANVAS, flags=flag, borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0))
    valid = cv2.warpAffine(np.full(img.shape[:2], 255, np.uint8), M, ANCHOR_CANVAS, flags=cv2.INTER_NEAREST,
                           borderMode=cv2.BORDER_CONSTANT, borderValue=0) > 0
    return canvas, valid


def align_image_ex(img: np.ndarray, settings: dict, colors: list[dict] | None = None) -> dict:
    """Alinhamento completo: {canvas, valid, box_found, method, note}. Função ÚNICA para referência e produção."""
    note = None
    if settings.get("align_mode") == "anchors" and colors:
        a = find_anchor(img, colors, settings.get("anchor_color", "RED"), float(settings["color_tolerance"]))
        if a is not None:
            canvas, valid = warp_by_anchor(img, a)
            return {"canvas": canvas, "valid": valid, "box_found": True, "method": "anchors", "note": None}
        note = f'Âncoras {settings.get("anchor_color", "RED")} não detetadas; usado o alinhamento por contorno.'
    cw, ch = int(settings["canvas_width"]), int(settings["canvas_height"])
    quad = detect_box(img, settings["min_box_area"])
    return {"canvas": warp_to_canvas(img, quad, cw, ch), "valid": None, "box_found": quad is not None,
            "method": "box", "note": note}


def align_image(img: np.ndarray, settings: dict, colors: list[dict] | None = None):
    """ÚNICO alinhamento do sistema: usado na imagem de referência (Engenharia) e na foto (Produção).
    Devolve (imagem canónica cw x ch, caixa_detetada)."""
    r = align_image_ex(img, settings, colors)
    return r["canvas"], r["box_found"]


def prepare_reference(img: np.ndarray, settings: dict, auto_crop: bool = True, colors: list[dict] | None = None):
    """Imagem de referência de um layout. `auto_crop` é ignorado de propósito: a referência passa
    exatamente pelo mesmo alinhamento da produção, para as regiões desenhadas coincidirem."""
    return align_image(img, settings, colors)


# --------------------------------------------------------------------- cores
def color_mask(hsv: np.ndarray, rgb: np.ndarray, cfg: dict, tol: float) -> np.ndarray:
    """Máscara booleana dos píxeis que correspondem à cor `cfg`, alargada por `tol` (0-50)."""
    p = cfg["params"]
    if cfg["mode"] == "rgb":
        diff = rgb.astype(np.float32) - np.array([p["r"], p["g"], p["b"]], np.float32)
        return np.sqrt((diff ** 2).sum(axis=-1)) <= p["distance"] + tol * 4.41
    d_sv = tol * 2.55
    lo = p["h_min"] - tol
    hi = (p["h_max"] if p["h_max"] >= p["h_min"] else p["h_max"] + 180) + tol  # gama que atravessa 0 (vermelho)
    width = hi - lo
    h = hsv[..., 0].astype(np.float32)
    hue_ok = np.ones(h.shape, bool) if width >= 179 else np.mod(h - lo, 180.0) <= width
    s, v = hsv[..., 1], hsv[..., 2]
    return (hue_ok & (s >= p["s_min"] - d_sv) & (s <= p["s_max"] + d_sv)
            & (v >= p["v_min"] - d_sv) & (v <= p["v_max"] + d_sv))


def color_preview(img: np.ndarray, cfg: dict, tol: float) -> np.ndarray:
    """Pré-visualização: realça a verde os píxeis que a cor captura."""
    img = limit_size(img, 800)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    m = color_mask(hsv, rgb, cfg, tol)
    out = img.copy()
    out[m] = (0.3 * img[m] + 0.7 * np.array([0, 255, 0])).astype(np.uint8)
    return out


# ------------------------------------------------------------------ avaliação
def build_candidates(canvas: np.ndarray, rot_tol: float, valid: np.ndarray | None = None) -> list[dict]:
    """Variantes da imagem alinhada: ângulos {-r,-r/2,0,r/2,r} x {0°,180°}."""
    h, w = canvas.shape[:2]
    angles = [0.0, -rot_tol / 2, rot_tol / 2, -rot_tol, rot_tol] if rot_tol > 0 else [0.0]
    out = []
    for flip in (0, 180):
        for a in angles:
            ang = a + flip
            v = valid
            if ang == 0:
                bgr = canvas
            else:
                M = cv2.getRotationMatrix2D((w / 2, h / 2), ang, 1.0)
                bgr = cv2.warpAffine(canvas, M, (w, h), borderMode=cv2.BORDER_REPLICATE)
                if valid is not None:
                    v = cv2.warpAffine(valid.astype(np.uint8) * 255, M, (w, h), flags=cv2.INTER_NEAREST) > 0
            out.append({"angle": ang, "bgr": bgr, "valid": v,
                        "hsv": cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV),
                        "rgb": cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)})
    return out


def _center_hsv(cfg: dict) -> tuple[float, float, float]:
    """Cor 'típica' (centro) de uma definição: a amostra medida no conta-gotas (c_h,c_s,c_v) ou o meio da gama."""
    p = cfg["params"]
    if cfg["mode"] == "rgb":
        h, s, v = cv2.cvtColor(np.uint8([[[p["b"], p["g"], p["r"]]]]), cv2.COLOR_BGR2HSV)[0, 0]
        return float(h), float(s), float(v)
    if all(k in p for k in ("c_h", "c_s", "c_v")):
        return float(p["c_h"]), float(p["c_s"]), float(p["c_v"])
    hmax = p["h_max"] if p["h_max"] >= p["h_min"] else p["h_max"] + 180
    return ((p["h_min"] + hmax) / 2) % 180, (p["s_min"] + p["s_max"]) / 2, (p["v_min"] + p["v_max"]) / 2


def _assign_fractions(ph, pr, valid, colors, tol) -> dict:
    """Fração de píxeis de cada cor. Quando as gamas de duas cores se sobrepõem (ex.: castanho e vermelho), cada píxel
    pertence à cor cujo centro lhe está mais próximo, por isso as frações passam a somar no máximo 100 %."""
    masks = [color_mask(ph, pr, c, tol) for c in colors]
    if valid is not None:
        masks = [m & valid for m in masks]
        n = float(valid.sum())
    else:
        n = float(masks[0].size)
    stack = np.stack(masks)
    ov = stack.sum(axis=0) > 1
    if ov.any():
        H = ph[..., 0][ov].astype(np.float32)
        S = ph[..., 1][ov].astype(np.float32)
        V = ph[..., 2][ov].astype(np.float32)
        dist = np.full((len(colors), H.size), np.inf, np.float32)
        for i, c in enumerate(colors):
            hc, sc, vc = _center_hsv(c)
            dh = np.abs(H - hc)
            dh = np.minimum(dh, 180 - dh)
            sat = (S + sc) / 2.0 / 255.0                      # a matiz pesa menos em cores pouco saturadas
            d = np.sqrt((2.0 * dh * sat) ** 2 + (0.5 * (S - sc)) ** 2 + (0.7 * (V - vc)) ** 2)
            dist[i] = np.where(stack[i][ov], d, np.inf)
        win = dist.argmin(axis=0)
        for i in range(len(colors)):
            stack[i][ov] = win == i
    return {c["name"]: float(stack[i].sum()) / max(1.0, n) for i, c in enumerate(colors)}


def _fractions(cand, rect, colors, tol) -> dict:
    x, y, w, h = rect
    H, W = cand["hsv"].shape[:2]
    x0, y0, x1, y1 = max(0, x), max(0, y), min(W, x + w), min(H, y + h)
    if x1 - x0 < 2 or y1 - y0 < 2:
        return {c["name"]: 0.0 for c in colors}
    ph, pr = cand["hsv"][y0:y1, x0:x1], cand["rgb"][y0:y1, x0:x1]
    vm = cand.get("valid")
    v = None
    if vm is not None:
        v = vm[y0:y1, x0:x1]
        if v.mean() < 0.5:  # a região está (quase) fora da fotografia: sem dados
            return None
    return _assign_fractions(ph, pr, v, colors, tol)


def _ring_fraction(cand, outer, inner, color_name, colors, tol) -> float:
    """Fração de píxeis da cor esperada no anel entre `inner` e `outer`."""
    cfg = next((c for c in colors if c["name"] == color_name), None)
    H, W = cand["hsv"].shape[:2]
    x0, y0 = max(0, outer[0]), max(0, outer[1])
    x1, y1 = min(W, outer[0] + outer[2]), min(H, outer[1] + outer[3])
    if cfg is None or x1 - x0 < 2 or y1 - y0 < 2:
        return 0.0
    m = color_mask(cand["hsv"][y0:y1, x0:x1], cand["rgb"][y0:y1, x0:x1], cfg, tol)
    valid = np.ones(m.shape, bool)
    if cand.get("valid") is not None:
        valid &= cand["valid"][y0:y1, x0:x1]
    ix, iy = max(0, inner[0] - x0), max(0, inner[1] - y0)
    valid[iy:iy + inner[3], ix:ix + inner[2]] = False
    n = int(valid.sum())
    return float((m & valid).sum()) / n if n else 0.0


def _eval_region(cand, reg, colors, tol, pos_pct) -> dict:
    H, W = cand["hsv"].shape[:2]
    rx, ry = int(reg["x"] * W), int(reg["y"] * H)
    rw, rh = max(2, int(reg["w"] * W)), max(2, int(reg["h"] * H))
    d = int(round(W * pos_pct / 100))
    offsets = [(0, 0)] + ([(dx, dy) for dx in (-d, 0, d) for dy in (-d, 0, d) if (dx, dy) != (0, 0)] if d > 0 else [])
    if reg["color"] == "EMPTY":  # ausência: verifica-se só na posição exata (deslizar poderia esconder um relé)
        offsets = [(0, 0)]
    best, best_rect = None, (rx, ry, rw, rh)
    for dx, dy in offsets:  # tolerância de posição; a região desenhada (0,0) tem prioridade
        rect = (rx + dx, ry + dy, rw, rh)
        fr = _fractions(cand, rect, colors, tol)
        if fr is None:
            continue
        if best is None or fr.get(reg["color"], 0.0) > best.get(reg["color"], 0.0) + 0.03:
            best, best_rect = fr, rect
    if best is None:  # região fora da fotografia
        return {"name": reg["name"], "expected": reg["color"], "detected": "SEM_DADOS", "fraction": 0.0,
                "ring": None, "reads": {}, "match": False, "rect": (rx, ry, rw, rh), "srect": (rx, ry, rw, rh)}
    detected, top = max(best.items(), key=lambda kv: kv[1])
    exp = best.get(reg["color"], 0.0)
    if top < 0.15:
        detected = "UNKNOWN"
    elif exp >= top - 0.05:  # gamas de cor sobrepostas: num empate (≤5 pontos) vale a cor esperada
        detected = reg["color"]
    frac = best.get(reg["color"], 0.0)
    match = detected == reg["color"] and frac >= reg["tolerance"] / 100.0
    # Contorno isolado (opcional): a cor esperada NÃO pode continuar para fora da região.
    # Distingue uma caixa pequena de caixas maiores que a contêm.
    ring = None
    margin = float(reg.get("ring_margin") or 0)
    if margin > 0:
        x, y, w, h = best_rect
        mx, my = max(3, int(w * margin / 100)), max(3, int(h * margin / 100))
        ring = _ring_fraction(cand, (x - mx, y - my, w + 2 * mx, h + 2 * my), best_rect, reg["color"], colors, tol)
        if ring * 100 > float(reg.get("ring_max", 25)):
            match = False
    return {"name": reg["name"], "expected": reg["color"], "detected": detected,
            "fraction": round(frac * 100, 1), "ring": None if ring is None else round(ring * 100, 1),
            "reads": {k: round(v * 100) for k, v in sorted(best.items(), key=lambda kv: -kv[1]) if v >= 0.10},
            "match": bool(match), "rect": (rx, ry, rw, rh), "srect": best_rect}


def evaluate_layout(cand, layout, colors, tol, pos_pct) -> dict:
    regs = [_eval_region(cand, r, colors, tol, pos_pct) for r in layout["regions"]]
    # Um objeto só pode satisfazer uma região: se, por causa do deslize de posição, duas regiões (desenhadas em
    # sítios diferentes) acabam a ler o mesmo sítio, a de menor cobertura falha.
    for i in range(len(regs)):
        for j in range(i + 1, len(regs)):
            a, b = regs[i], regs[j]
            if (a["match"] and b["match"] and "EMPTY" not in (a["expected"], b["expected"])
                    and _iou(a["srect"], b["srect"]) > 0.4 and _iou(a["rect"], b["rect"]) < 0.4):
                (a if a["fraction"] < b["fraction"] else b)["match"] = False
    n = max(1, len(regs))
    return {"layout_id": layout["id"], "layout": layout["name"], "model_code": layout["model_code"],
            "model_name": layout["model_name"], "min_confidence": layout.get("min_confidence"),
            "angle": cand["angle"], "regions": regs,
            "score": round(100.0 * sum(r["match"] for r in regs) / n, 1),
            "quality": sum(r["fraction"] for r in regs) / n,
            "matched": sum(r["match"] for r in regs), "total": len(regs), "_cand": cand}


def _iou(a, b) -> float:
    ix = max(0, min(a[0] + a[2], b[0] + b[2]) - max(a[0], b[0]))
    iy = max(0, min(a[1] + a[3], b[1] + b[3]) - max(a[1], b[1]))
    inter = ix * iy
    return inter / float(a[2] * a[3] + b[2] * b[3] - inter) if inter else 0.0


def _is_subset(small: list[dict], big: list[dict]) -> bool:
    """Todas as regiões de `small` existem em `big` (mesma posição e cor esperada)?"""
    return all(any(s["expected"] == b["expected"] and _iou(s["rect"], b["rect"]) > 0.5 for b in big) for s in small)


def annotate(cand_bgr: np.ndarray, regions: list[dict]) -> np.ndarray:
    out = cand_bgr.copy()
    for r in regions:
        x, y, w, h = r["rect"]
        col = (60, 170, 30) if r["match"] else (40, 40, 220)
        cv2.rectangle(out, (x, y), (x + w, y + h), (0, 0, 0), 4)
        cv2.rectangle(out, (x, y), (x + w, y + h), col, 2)
        txt = f'{r["name"]}:{r["detected"]}'
        cv2.putText(out, txt, (x + 3, max(14, y - 5)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 3, cv2.LINE_AA)
        cv2.putText(out, txt, (x + 3, max(14, y - 5)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
    return out


def run_identification(img: np.ndarray, layouts: list[dict], colors: list[dict], settings: dict) -> dict:
    """Identifica o modelo. `layouts` = [{id,name,model_code,model_name,regions:[...]}]."""
    al = align_image_ex(img, settings, colors)
    box_found = al["box_found"]
    cands = build_candidates(al["canvas"], float(settings["rotation_tolerance"]), al["valid"])
    tol, pos = float(settings["color_tolerance"]), float(settings["position_tolerance"])

    per_layout = []
    base_cand = cands[0]  # ângulo 0, sem rotação: é exatamente a imagem alinhada (= referência)
    for lay in layouts:
        # 1) Leitura exata nas posições desenhadas, sem qualquer tolerância de posição/rotação.
        best = evaluate_layout(base_cand, lay, colors, tol, 0.0)
        best["exact"] = True
        # 2) Só se a leitura exata não for perfeita procuramos rotação/deslocamento.
        if best["score"] < 100.0:
            for cand in cands:
                ev = evaluate_layout(cand, lay, colors, tol, pos)
                ev["exact"] = False
                if (ev["score"] > best["score"]
                        or (ev["score"] == best["score"] and ev["quality"] > best["quality"] + 1.0)):
                    best = ev
        per_layout.append(best)

    key = lambda e: (e["score"], e["matched"], e["exact"], e["quality"])  # empate: mais específico / leitura exata
    by_model: dict[str, dict] = {}
    for ev in per_layout:
        cur = by_model.get(ev["model_code"])
        if cur is None or key(ev) > key(cur):
            by_model[ev["model_code"]] = ev
    ranking = sorted(by_model.values(), key=key, reverse=True)
    best = ranking[0]
    second = ranking[1] if len(ranking) > 1 else None
    margin = best["score"] - second["score"] if second else 100.0

    reasons, warnings = [], []
    if not box_found:
        msg = "Fuse Box não detetada na fotografia (foi usada a imagem inteira)."
        (reasons if settings["require_box"] else warnings).append(msg)
    if al["note"] and box_found:
        warnings.append(al["note"])
    # mínimo do próprio modelo (se definido) ou o global das Tolerâncias
    min_conf = best["min_confidence"] if best.get("min_confidence") is not None else settings["min_confidence"]
    if best["score"] < min_conf:
        reasons.append(f'Confiança {best["score"]}% abaixo do mínimo exigido ({min_conf:g}%).')
    if second and margin < settings["min_margin"]:
        tie_resolved = margin < 0.05 and (best["matched"] > second["matched"]
                                           or (best["exact"] and not second["exact"]))
        if not tie_resolved:
            reasons.append(f'Ambiguidade: {best["model_code"]} ({best["score"]}%) e {second["model_code"]} '
                           f'({second["score"]}%) não se distinguem. Adicione regiões que os separem.')
    # Salvaguarda de subconjunto: o vencedor só tem regiões que outro modelo (com mais regiões) também tem,
    # e esse outro quase coincide -> a evidência não separa os dois.
    for other in ranking[1:]:
        if not (other["total"] > best["total"] and other["score"] >= min_conf - 15
                and _is_subset(best["regions"], other["regions"])):
            continue
        extras = [b for b in other["regions"]
                  if not any(sr["expected"] == b["expected"] and _iou(sr["rect"], b["rect"]) > 0.5 for sr in best["regions"])]
        # diferença clara (região lê outra cor, sem vestígio da esperada) resolve; falha duvidosa não
        weak = [b for b in extras if not b["match"] and (b["detected"] in ("UNKNOWN", "SEM_DADOS") or b["fraction"] >= 25)]
        if weak:
            reasons.append(f'{best["model_code"]} é um subconjunto de {other["model_code"]}, que quase coincide '
                           f'({other["score"]}%). Confirme manualmente ou acrescente regiões que os distingam.')
            break
    status = "PASS" if not reasons else "FAIL"

    return {
        "status": status, "model_code": best["model_code"], "model_name": best["model_name"],
        "layout": best["layout"], "confidence": best["score"], "min_confidence_used": min_conf, "margin": round(margin, 1),
        "box_found": box_found, "alignment": al["method"], "angle": best["angle"], "reasons": reasons, "warnings": warnings,
        "regions": [{k: v for k, v in r.items() if k not in ("rect", "srect")} for r in best["regions"]],
        "ranking": [{"model_code": e["model_code"], "model_name": e["model_name"], "layout": e["layout"],
                     "score": e["score"], "matched": e["matched"], "total": e["total"],
                     "regions": [{k: v for k, v in r.items() if k not in ("rect", "srect")} for r in e["regions"]]} for e in ranking],
        "annotated": annotate(best["_cand"]["bgr"], best["regions"]),
    }
