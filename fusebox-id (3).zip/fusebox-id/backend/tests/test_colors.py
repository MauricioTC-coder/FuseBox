"""Cores sobrepostas (castanho dentro da gama do vermelho): cada píxel vai para a cor com o centro mais próximo."""
import copy

import cv2
import numpy as np

from app import vision
from app.db import DEFAULT_COLORS

COLORS = [{"name": n, "mode": m, "params": dict(p)} for n, m, p in DEFAULT_COLORS]


def cand(h, s, v):
    hsv = np.zeros((40, 60, 3), np.uint8)
    hsv[...] = (h, s, v)
    return {"hsv": hsv, "rgb": cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB), "valid": None}


def frac(c, colors, tol=10):
    return vision._fractions(c, (0, 0, 60, 40), colors, tol)


def with_centers():
    cols = copy.deepcopy(COLORS)
    for c in cols:  # centros medidos (conta-gotas) nas fotos reais
        if c["name"] == "BROWN":
            c["params"].update(c_h=3, c_s=120, c_v=135)
        if c["name"] == "RED":
            c["params"].update(c_h=179, c_s=150, c_v=250)
    return cols


def test_brown_relay_inside_red_range_is_brown_with_measured_centers():
    cols = with_centers()
    f = frac(cand(4, 118, 140), cols)          # relé castanho (H 2-5, S 108-136, V 99-162)
    print("castanho:", {k: round(v, 2) for k, v in f.items() if v})
    assert f["BROWN"] > 0.95 and f["RED"] < 0.05


def test_red_relay_stays_red_and_fractions_never_exceed_100():
    cols = with_centers()
    f = frac(cand(178, 150, 248), cols)         # relé vermelho (H 178-2, S 110-175, V 241-255)
    print("vermelho:", {k: round(v, 2) for k, v in f.items() if v})
    assert f["RED"] > 0.95 and f["BROWN"] < 0.05
    for px in ((4, 118, 140), (178, 150, 248), (12, 191, 120), (5, 100, 180)):  # mesmo com as gamas por defeito
        assert sum(frac(cand(*px), COLORS).values()) <= 1.0001
