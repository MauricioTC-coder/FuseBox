"""Teste ponta-a-ponta com Fuse Boxes sintéticas (gera fotos com rotação/perspetiva)."""
import os
import tempfile

import cv2
import numpy as np

os.environ["FUSEBOX_DATA_DIR"] = tempfile.mkdtemp()

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402

BGR = {"BLUE": (200, 60, 20), "RED": (30, 30, 200), "BROWN": (30, 70, 120), "GRAY": (130, 130, 130), "EMPTY": (10, 10, 10)}
LAYOUT_A = ["BLUE", "BLUE", "BLUE", "BLUE", "BLUE", "BLUE", "GRAY", "BROWN"]
LAYOUT_B = ["BLUE", "BLUE", "RED", "RED", "BLUE", "BLUE", "EMPTY", "BROWN"]


def cell_rect(i):
    c, r = i % 4, i // 4
    return 0.05 + c * 0.235, 0.1 + r * 0.45, 0.2, 0.35


def canvas(pattern):
    img = np.full((600, 800, 3), 35, np.uint8)
    for i, name in enumerate(pattern):
        x, y, w, h = cell_rect(i)
        cv2.rectangle(img, (int(x * 800), int(y * 600)), (int((x + w) * 800), int((y + h) * 600)), BGR[name], -1)
    return img


def photo(pattern, angle=6, flip=False):
    can = pattern if isinstance(pattern, np.ndarray) else canvas(pattern)
    src = np.float32([[0, 0], [800, 0], [800, 600], [0, 600]])
    a = np.deg2rad(angle)
    R = np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]])
    dst = (src * 0.8 - [400, 300]) @ R.T + [700, 500] + np.array([[0, 0], [12, 4], [15, 10], [0, 8]])
    M = cv2.getPerspectiveTransform(src, dst.astype("float32"))
    bg = cv2.warpPerspective(can, M, (1400, 1000), borderValue=(215, 215, 215))
    if flip:
        bg = cv2.rotate(bg, cv2.ROTATE_180)
    return cv2.imencode(".jpg", bg)[1].tobytes()


def test_full_flow():
    with TestClient(app) as cl:
        tok = cl.post("/api/auth/login", json={"password": "engenharia"}).json()["token"]
        H = {"X-Eng-Token": tok}
        assert cl.post("/api/auth/login", json={"password": "x"}).status_code == 401
        assert cl.post("/api/models", json={"code": "AM", "name": "AM"}).status_code == 401
        for code, pat in (("AM", LAYOUT_A), ("AC", LAYOUT_B)):
            mid = cl.post("/api/models", json={"code": code, "name": code}, headers=H).json()["id"]
            r = cl.post(f"/api/models/{mid}/layouts", data={"name": "std"},
                        files={"image": ("r.jpg", photo(pat, 0), "image/jpeg")}, headers=H)
            assert r.status_code == 201 and r.json()["box_found"], r.text
            regs = [{"name": f"R{i+1}", "x": cell_rect(i)[0], "y": cell_rect(i)[1], "w": cell_rect(i)[2],
                     "h": cell_rect(i)[3], "color": c, "tolerance": 60} for i, c in enumerate(pat)]
            assert cl.put(f"/api/layouts/{r.json()['id']}/regions", json={"regions": regs}, headers=H).status_code == 200
        for pat, exp, flip in ((LAYOUT_A, "AM", False), (LAYOUT_B, "AC", False), (LAYOUT_A, "AM", True)):
            res = cl.post("/api/identify", data={"operator": "teste"},
                          files={"image": ("p.jpg", photo(pat, 7, flip), "image/jpeg")}).json()
            print(exp, res["model_code"], res["confidence"], res["ranking"], res["status"])
            assert res["model_code"] == exp and res["status"] == "PASS", res
        assert cl.get("/api/history").json()["total"] == 3
        assert cl.get("/api/dashboard").json()["today"]["total"] == 3
        exp = cl.get("/api/config/export", headers=H).json()
        assert len(exp["models"]) == 2
        assert cl.post("/api/config/import?replace=true", json=exp, headers=H).json()["models"] == 2
        assert cl.get("/api/backup", headers=H).status_code == 200


def test_same_image_same_regions_and_subset_tie():
    """A mesma foto usada como referência e como teste: ângulo 0, 100%, PASS; e um modelo cujas regiões
    são um subconjunto de outro não pode provocar FAIL por empate."""
    with TestClient(app) as cl:
        tok = cl.post("/api/auth/login", json={"password": "engenharia"}).json()["token"]
        H = {"X-Eng-Token": tok}
        for m in cl.get("/api/models").json():  # isolar do teste anterior
            cl.delete(f"/api/models/{m['id']}", headers=H)
        ref = photo(LAYOUT_A, 4)
        mk = lambda code, n: cl.post("/api/models", json={"code": code, "name": code}, headers=H).json()["id"]
        for code, count in (("FULL", 8), ("SUB", 4)):
            mid = mk(code, count)
            r = cl.post(f"/api/models/{mid}/layouts", data={"name": "std"}, files={"image": ("r.jpg", ref, "image/jpeg")}, headers=H).json()
            regs = [{"name": f"R{i+1}", "x": cell_rect(i)[0], "y": cell_rect(i)[1], "w": cell_rect(i)[2], "h": cell_rect(i)[3],
                     "color": LAYOUT_A[i], "tolerance": 60} for i in range(count)]
            assert cl.put(f"/api/layouts/{r['id']}/regions", json={"regions": regs}, headers=H).status_code == 200
        res = cl.post("/api/identify", data={"operator": "t"}, files={"image": ("p.jpg", ref, "image/jpeg")}).json()
        print(res["model_code"], res["angle"], res["confidence"], res["ranking"], res["reasons"])
        assert res["model_code"] == "FULL" and res["angle"] == 0 and res["confidence"] == 100 and res["status"] == "PASS", res


def test_identical_image_is_pixel_consistent():
    """Foto = referência (mesmo ficheiro, incluindo sem caixa detetável): 100 %, ângulo 0, PASS."""
    with TestClient(app) as cl:
        tok = cl.post("/api/auth/login", json={"password": "engenharia"}).json()["token"]
        H = {"X-Eng-Token": tok}
        for m in cl.get("/api/models").json():
            cl.delete(f"/api/models/{m['id']}", headers=H)
        for data in (cv2.imencode(".jpg", canvas(LAYOUT_A))[1].tobytes(), photo(LAYOUT_A, 9)):
            mid = cl.post("/api/models", json={"code": "ONE", "name": "ONE"}, headers=H).json()["id"]
            r = cl.post(f"/api/models/{mid}/layouts", data={"name": "std"}, files={"image": ("r.jpg", data, "image/jpeg")}, headers=H).json()
            regs = [{"name": f"R{i+1}", "x": cell_rect(i)[0], "y": cell_rect(i)[1], "w": cell_rect(i)[2], "h": cell_rect(i)[3],
                     "color": LAYOUT_A[i], "tolerance": 60} for i in range(8)]
            cl.put(f"/api/layouts/{r['id']}/regions", json={"regions": regs}, headers=H)
            res = cl.post("/api/identify", data={"operator": "t"}, files={"image": ("p.jpg", data, "image/jpeg")}).json()
            print(res["box_found"], res["angle"], res["confidence"], res["status"], res["reasons"], res["warnings"])
            assert res["angle"] == 0 and res["confidence"] == 100 and res["status"] == "PASS", res
            cl.delete(f"/api/models/{mid}", headers=H)


def test_min_confidence_manual_and_per_model():
    """75 % (6/8 regiões) dá FAIL com mínimo 90 e PASS quando o mínimo baixa (global ou por modelo)."""
    with TestClient(app) as cl:
        tok = cl.post("/api/auth/login", json={"password": "engenharia"}).json()["token"]
        H = {"X-Eng-Token": tok}
        for m in cl.get("/api/models").json():
            cl.delete(f"/api/models/{m['id']}", headers=H)
        mid = cl.post("/api/models", json={"code": "MM", "name": "MM"}, headers=H).json()["id"]
        r = cl.post(f"/api/models/{mid}/layouts", data={"name": "s"}, files={"image": ("r.jpg", photo(LAYOUT_A, 0), "image/jpeg")}, headers=H).json()
        regs = [{"name": f"R{i+1}", "x": cell_rect(i)[0], "y": cell_rect(i)[1], "w": cell_rect(i)[2], "h": cell_rect(i)[3],
                 "color": LAYOUT_A[i], "tolerance": 60} for i in range(8)]
        cl.put(f"/api/layouts/{r['id']}/regions", json={"regions": regs}, headers=H)
        bad = list(LAYOUT_A); bad[0] = bad[1] = "RED"  # 2 regiões erradas -> 75 %
        ident = lambda: cl.post("/api/identify", data={"operator": "t", "dry_run": "true"}, files={"image": ("p.jpg", photo(bad, 0), "image/jpeg")}).json()
        cl.put("/api/settings", json={"min_confidence": 90}, headers=H)
        a = ident(); print(a["confidence"], a["status"], a["min_confidence_used"])
        assert a["confidence"] == 75 and a["status"] == "FAIL"
        cl.put("/api/settings", json={"min_confidence": 70}, headers=H)
        assert ident()["status"] == "PASS"
        cl.put("/api/settings", json={"min_confidence": 90}, headers=H)
        cl.put(f"/api/models/{mid}", json={"code": "MM", "name": "MM", "min_confidence": 70}, headers=H)
        b = ident(); assert b["status"] == "PASS" and b["min_confidence_used"] == 70, b


def test_ring_separates_small_box_inside_bigger_boxes():
    """AT = caixa pequena DENTRO das caixas grandes do AS. Sem contorno: empate 100 %/100 %.
    Com 'contorno isolado': o AS deixa de ser confundido com o AT."""
    as_pat = ["BLUE", "BLUE"] + ["EMPTY"] * 6
    at_img = np.full((600, 800, 3), 35, np.uint8)
    cv2.rectangle(at_img, (96, 141), (144, 189), BGR["BLUE"], -1)  # pequena, dentro da célula 0
    small = {"name": "R1", "x": 96 / 800, "y": 141 / 600, "w": 48 / 800, "h": 48 / 600, "color": "BLUE", "tolerance": 90}
    empty5 = {"name": "R2", "x": cell_rect(5)[0], "y": cell_rect(5)[1], "w": cell_rect(5)[2], "h": cell_rect(5)[3], "color": "EMPTY", "tolerance": 60}
    with TestClient(app) as cl:
        tok = cl.post("/api/auth/login", json={"password": "engenharia"}).json()["token"]
        H = {"X-Eng-Token": tok}
        for m in cl.get("/api/models").json():
            cl.delete(f"/api/models/{m['id']}", headers=H)
        cl.put("/api/settings", json={"min_confidence": 90, "min_margin": 5}, headers=H)

        def make(code, img, regs):
            mid = cl.post("/api/models", json={"code": code, "name": code}, headers=H).json()["id"]
            lid = cl.post(f"/api/models/{mid}/layouts", data={"name": "s"}, files={"image": ("r.jpg", photo(img, 0), "image/jpeg")}, headers=H).json()["id"]
            assert cl.put(f"/api/layouts/{lid}/regions", json={"regions": regs}, headers=H).status_code == 200
            return lid
        as_regs = [{"name": f"R{i+1}", "x": cell_rect(i)[0], "y": cell_rect(i)[1], "w": cell_rect(i)[2], "h": cell_rect(i)[3], "color": "BLUE", "tolerance": 60} for i in range(2)]
        make("AS", canvas(as_pat), as_regs)
        at = make("AT", at_img, [small, empty5])
        ident = lambda img: cl.post("/api/identify", data={"operator": "t", "dry_run": "true"}, files={"image": ("p.jpg", photo(img, 5), "image/jpeg")}).json()

        r = ident(canvas(as_pat))  # sem contorno: o AT também chega a 100 %
        print("sem contorno:", [(x["model_code"], x["score"]) for x in r["ranking"]], r["status"])
        assert {x["model_code"]: x["score"] for x in r["ranking"]}["AT"] == 100

        cl.put(f"/api/layouts/{at}/regions", json={"regions": [dict(small, ring_margin=60, ring_max=25), empty5]}, headers=H)
        r = ident(canvas(as_pat))
        print("com contorno:", [(x["model_code"], x["score"]) for x in r["ranking"]], r["status"])
        assert r["model_code"] == "AS" and r["status"] == "PASS", r
        r = ident(at_img)  # a foto do AT continua a dar AT
        assert r["model_code"] == "AT" and r["status"] == "PASS", r


def test_starter_config_anchors_robust():
    """Importa a configuração inicial (alinhamento por âncoras) e reidentifica as imagens de referência
    com zoom/rotação/deslocamento: nunca PASS errado e todas as caixas ativas corretas."""
    import base64, json, pathlib
    cfg = json.loads((pathlib.Path(__file__).resolve().parents[2] / "config" / "modelos_iniciais.json").read_text())
    with TestClient(app) as cl:
        tok = cl.post("/api/auth/login", json={"password": "engenharia"}).json()["token"]
        H = {"X-Eng-Token": tok}
        assert cl.post("/api/config/import?replace=true", json=cfg, headers=H).status_code == 200
        assert cl.get("/api/settings").json()["align_mode"] == "anchors"
        ok = 0
        for m in cfg["models"]:
            if not m["active"]:
                continue
            ref = cv2.imdecode(np.frombuffer(base64.b64decode(m["layouts"][0]["image_b64"]), np.uint8), 1)
            h, w = ref.shape[:2]
            M = cv2.getRotationMatrix2D((w / 2, h / 2), 3.0, 0.9); M[:, 2] += (20, -15)
            test = cv2.warpAffine(ref, M, (w, h), borderMode=cv2.BORDER_REPLICATE)
            r = cl.post("/api/identify", data={"operator": "t", "dry_run": "true"},
                        files={"image": ("t.jpg", cv2.imencode(".jpg", test)[1].tobytes(), "image/jpeg")}).json()
            print(m["code"], r["model_code"], r["confidence"], r["status"], r["alignment"])
            assert not (r["status"] == "PASS" and r["model_code"] != m["code"]), r
            ok += r["status"] == "PASS" and r["model_code"] == m["code"]
        assert ok >= 5
