# Análise das 9 fotografias (AC, AK, AM, AN, AP, AQ, AR, AS, AT)

## 1. O que distingue os modelos
Em todos os modelos o painel de fusíveis e os 2 relés vermelhos grandes são iguais. O que varia são os relés da zona superior.
Posições ("slots") na imagem alinhada: T (topo), B (castanho, por baixo do T), L / G / R (grandes: azul, cinzento, azul),
s1–s4 (pequenos azuis).

| Modelo | T | B | L G R | s1 | s2 | s3 | s4 | Nota |
|---|---|---|---|---|---|---|---|---|
| AC | azul | **castanho** | sim | sim | sim | **vazio** | sim | |
| AK / AT | azul | vazio | sim | sim | sim | sim | sim | iguais nos relés |
| AM | azul | **castanho** | sim | sim | sim | sim | sim | |
| AN / AP | ? | ? | sim | sim | sim | sim | sim | foto cortada em cima; AN e AP são a mesma imagem |
| AQ | vazio | vazio | sim | sim | sim | vazio | vazio | |
| AR | vazio | vazio | sim | sim | sim | sim | vazio | |
| AS | azul | vazio | sim | sim | sim | **vazio** | sim | |

Pares a **uma só posição de diferença**: AC–AM (s3), AM–AK/AT (B), AS–AK/AT (s3), AQ–AR (s3), AS–AC (B).
Por isso, com estes modelos, uma confiança mínima abaixo de 100 % é arriscada.

## 2. Problemas encontrados nas fotos / no sistema
1. **Alinhamento**: nas fotos com moldura preta, a "caixa detetada" era a moldura da própria fotografia (99,7 % da imagem) e as
   fotos retrato eram rodadas 90° e esticadas. A caixa aparecia em tamanhos/posições diferentes (até 60 % maior em AN/AP).
   Corrigido com o alinhamento por **âncoras de cor** (relés vermelhos).
2. **Cores**: o BLUE por defeito não apanha o azul-ciano dos relés (H 94–100, S 62–165, V 228–255) e o castanho caía no vermelho.
3. **Ausências**: só desenhar regiões nos relés presentes cria modelos "subconjunto" de outros (ex.: AS dentro de AT).
   Desenhar também as posições que devem estar **vazias** (EMPTY).
4. **Fotos**: AK tem um retângulo cinzento por cima da posição B (editado); AN e AP são a mesma foto, cortada sem o topo;
   AN/AP vistas de muito perto (parallax: os relés, mais altos, ficam deslocados 30–60 px).
5. **AN_AP_AS**: pelas fotos, o AS (3 relés pequenos, com T) não tem os mesmos relés que AN/AP (4 pequenos). Confirmar.

## 3. Resultados dos testes (alinhamento por âncoras)
- Cada foto original → modelo correto, 100 %.
- 63 imagens (9 fotos × original + 6 variações agressivas: zoom 0,8–1,25×, rotação ±6°, deslocamento ±5 %, brilho ±20 %,
  desfocagem, JPEG qualidade 55–90): 39 a 52 PASS corretos; os restantes dão FAIL (falha segura); 1–2 PASS errados,
  sempre para AN_AP (referência sem T/B nem ausências).
