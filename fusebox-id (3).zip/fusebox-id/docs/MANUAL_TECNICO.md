# Manual Técnico — FuseBox ID

## 1. Arquitetura
```
Browser (React + MUI) ──HTTP──> nginx ──/api──> FastAPI (uvicorn) ──> SQLite + pasta de imagens
                                                   └─ OpenCV (vision.py)
```
Sem ML: apenas contornos, transformação de perspetiva, rotação, máscaras HSV/RGB e contagem de píxeis.

## 2. Pipeline de visão (`backend/app/vision.py`)
1. **Deteção** (`detect_box`): imagem reduzida a ≤800 px; máscaras Canny+dilatação, Otsu e Otsu invertido;
   fecho morfológico; maior contorno externo com área ≥ *área mínima* e preenchimento do retângulo ≥ 0,6;
   `minAreaRect` → 4 cantos.
2. **Alinhamento** (`warp_to_canvas`): transformação de perspetiva para uma imagem canónica
   (800×600 por defeito), lado maior na horizontal.
3. **Rotação** (`build_candidates`): variantes {−r, −r/2, 0, +r/2, +r}° × {0°, 180°}, com r = tolerância de rotação.
4. **Regiões** (`_eval_region`): regiões em coordenadas normalizadas 0–1. Para cada região testa 3×3
   deslocamentos (± tolerância de posição) e fica com o que melhor cobre a cor esperada.
5. **Cor** (`color_mask`): fração de píxeis da região dentro de cada gama de cor.
   - HSV (escala OpenCV): H±tol, S/V±tol·2,55; suporta gama que atravessa 0 (vermelho).
   - RGB: distância euclidiana ≤ distância + tol·4,41.
   - Cor lida = a de maior fração (UNKNOWN se < 15 %).
   - Região **coincide** se cor lida = esperada e fração ≥ tolerância da região.
5b. **Contorno isolado** (opcional por região, `ring_margin`/`ring_max`): fração da cor esperada no anel entre a região e a região
   expandida; se exceder `ring_max` %, a região não coincide.
6. **Score** por layout = % de regiões coincidentes; para cada modelo conta o melhor layout/ângulo.
7. **Decisão**: PASS se caixa detetada (se exigido), confiança ≥ mínima e margem para o 2.º modelo ≥ mínima.

Limitação assumida: o alinhamento depende do contorno exterior da caixa; fundo/contraste razoável é necessário.
Se as suas caixas exigirem alinhamento por pontos de referência internos, o ponto de extensão é `warp_to_canvas`.

### 2.0 Alinhamento por âncoras (Tolerâncias → Alinhamento)
`align_mode=anchors`: o maior bloco da cor-âncora (por defeito RED = os 2 relés vermelhos) define centro, largura (escala) e
inclinação; a imagem é levada a 600×800 com a âncora em (470, 460) e largura 100 px. Zonas fora da fotografia ficam inválidas
("SEM_DADOS" na região, que então não coincide). Se a âncora não for encontrada, usa-se o contorno da caixa e mostra-se aviso.
Regiões EMPTY lêem-se só na posição exata; um objeto não satisfaz duas regiões; salvaguarda de subconjunto (um modelo cujas
regiões são todas de outro, que quase coincide, exige confirmação). Limitação: parallax em fotos de muito perto.

### 2.1 Alinhamento único (engenharia = produção)
`align_image()` é a única função de alinhamento: decodifica → reduz a ≤1920 px → `detect_box` → perspetiva para
800×600. É usada tanto ao criar/substituir a imagem de referência como em cada identificação, por isso uma foto
idêntica produz a mesma imagem alinhada. As regiões são desenhadas sobre essa imagem e guardadas em proporção (0–1).
Leitura exata primeiro (ângulo 0, sem deslocamento); só se não der 100 % se procura rotação/deslocamento. Desempates favorecem a posição desenhada: ângulo 0 primeiro, deslocamento (0,0) primeiro (só desloca se melhorar
>3 pontos), e a imagem anotada mostra sempre as regiões nas posições configuradas. Se a caixa não for detetada,
usa-se a imagem inteira e mostra-se um aviso (ou FAIL se "Exigir deteção" estiver ativo).
Empate entre modelos: vence o que tem mais regiões coincidentes; se continuar empatado é ambiguidade (FAIL).

## 3. Base de dados (SQLite, `data/fusebox.db`, modo WAL)
`settings` · `colors` · `models` · `layouts` (1 modelo → N layouts, com imagem de referência) ·
`regions` (por layout) · `history`. Imagens em `data/images/{ref,hist}`. Chaves `_secret_key` e `_eng_password`
(hash PBKDF2-SHA256, 200 000 iterações) ficam em `settings` e nunca são exportadas.

## 4. API REST (`/api`, documentação interativa em `/docs`)
Públicas: `GET /health`, `POST /auth/login`, `GET /models`, `GET /layouts/{id}[/image]`, `GET /colors`,
`GET /settings`, `POST /identify` (multipart: image, operator, dry_run), `GET /history[...]`, `GET /dashboard`.
Engenharia (cabeçalho `X-Eng-Token`): CRUD de `/models`, `/layouts`, `PUT /layouts/{id}/regions`,
`PUT|DELETE /colors/{name}`, `POST /colors/preview`, `PUT /settings`, `GET /config/export`,
`POST /config/import?replace=`, `GET /backup`, `POST /history/purge`, `POST /auth/password`.

## 5. Segurança
Token HMAC-SHA256 com expiração (`FUSEBOX_TOKEN_TTL`); bloqueio de 5 min após 5 tentativas falhadas por IP
(contador por processo). Serviço em rede interna: publique apenas o nginx. Para acesso fora da fábrica use HTTPS
(necessário também para a webcam no browser, exceto em `localhost`; o botão "Tirar fotografia" funciona em HTTP).

## 6. Instalação e operação (apenas Python)
- **Arquitetura de execução**: um único processo `uvicorn` serve a API (`/api`) e a interface compilada (`backend/web`).
- **Windows**: `iniciar.bat` → `run.py`. **Ubuntu**: `./iniciar.sh` → `run.py`. O `run.py` cria `.venv`,
  instala `backend/requirements.txt` (reinstala se o ficheiro mudar, via hash em `.venv/.req_hash`), lê o `.env` e arranca.
- **Serviço**: Ubuntu `sudo ./instalar_servico.sh` (systemd `fusebox.service`); Windows `iniciar_com_windows.bat` (tarefa agendada).
- **Variáveis** (`.env`): `FUSEBOX_HOST`, `FUSEBOX_PORT`, `FUSEBOX_ENG_PASSWORD` (só 1.º arranque), `FUSEBOX_TOKEN_TTL`,
  `FUSEBOX_DATA_DIR`, `FUSEBOX_WORKERS`, `FUSEBOX_MAX_UPLOAD_MB`, `FUSEBOX_WEB_DIR`.
- **Backup**: Engenharia → Sistema → Backup (ZIP), ou copiar `data/` com o serviço parado. **Restauro**: parar, repor `data/`, arrancar.
- **Atualização**: descompactar por cima (mantendo `data/` e `.env`) e voltar a executar o `iniciar`.
- **HTTPS**: a webcam do browser exige HTTPS (exceto em `localhost`); o botão "Tirar fotografia" funciona em HTTP.
  Para HTTPS coloque um proxy (nginx/Caddy) à frente da porta 8080.
- **Docker** (opcional): `docker-compose.yml` continua disponível, mas não é necessário.

## 7. Recuperar a password de engenharia
```bash
cd backend && ../.venv/bin/python -c "from app.auth import set_password; set_password('NovaPassword')"   # Windows: ..\.venv\Scripts\python.exe
```
(definir antes `FUSEBOX_DATA_DIR` para a pasta `data/` do projeto, se não estiver no `.env`; no Windows PowerShell: `$env:FUSEBOX_DATA_DIR="..\data"`).

## 8. Testes e extensão
`pytest -q -s backend/tests` gera fotos sintéticas (rotação, perspetiva, caixa invertida) e valida o fluxo completo.
Novos tipos de cor/regra: `color_mask` (vision.py). Novos relatórios: `service.dashboard`.
Escala: SQLite + 2 workers cobre uma linha; para várias linhas simultâneas aumente workers ou migre `db.py` para PostgreSQL.

## 9. Calibração recomendada (1.ª instalação)
1. Fixar câmara/iluminação. 2. Criar modelos com 1 foto de referência boa cada. 3. Ajustar **Cores** com fotos reais.
4. Desenhar regiões só nos cavidades/fusíveis que distinguem modelos. 5. Validar com ≥20 fotos por modelo
(Editor → *Testar com fotografia*) e só então ajustar tolerâncias.
