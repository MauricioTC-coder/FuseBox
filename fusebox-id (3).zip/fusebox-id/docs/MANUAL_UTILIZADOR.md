# Manual do Utilizador — FuseBox ID

## 1. Operador: identificar uma Fuse Box
1. Abra a aplicação e vá a **Identificar**.
2. Escreva o seu nome em **Operador** (fica memorizado).
3. Toque **Tirar fotografia** (telemóvel/tablet), **Webcam** ou **Escolher ficheiro**.
4. A análise demora normalmente 1–2 s. O ecrã mostra:
   - **Modelo detetado** e **Confiança** (% de regiões que coincidem);
   - **PASS** (verde) ou **FAIL** (vermelho), com o motivo em caso de falha;
   - comparação com todos os modelos, tabela de regiões (esperado vs. lido) e a imagem alinhada com as regiões
     (verde = coincide, vermelho = não coincide).

Boas fotografias: caixa inteira visível, fundo liso e contrastante, luz uniforme, sem reflexos, câmara de frente.

## 2. Histórico
**Histórico**: pesquise por modelo, operador, estado e datas. Clique numa linha para ver o resultado e a imagem.

## 3. Dashboard
Produção do dia, PASS/FAIL, taxa de acerto, modelos mais frequentes e produção por dia/hora (atualiza sozinho).

## 4. Modo Engenharia (password)
Entre em **Engenharia**. A sessão termina ao fim de 1 h ou com *Terminar sessão*.

### 4.1 Criar um modelo e o seu layout
1. **Modelos → Novo modelo**: código (ex.: `AN_AP_AS`), nome e descrição.
2. **Adicionar layout**: escolha uma fotografia de referência de uma Fuse Box desse modelo.
   A fotografia é endireitada automaticamente, exatamente como na produção. Um modelo pode ter vários layouts (variantes).
3. Abre-se o **Editor de regiões**.

### 4.2 Editor de regiões
- **Desenhar**: arraste numa zona vazia da imagem. **Mover**: arraste dentro da região.
  **Redimensionar**: arraste um canto. **Apagar**: tecla Delete ou ícone do lixo.
- Em cada região defina **Nome** (R1, R2…), **Cor esperada** e **Tolerância** (cobertura mínima de píxeis
  dessa cor, por defeito 60 %). Clique **Guardar regiões**.
- **Testar com fotografia**: corre a identificação sem gravar no histórico. Use-o sempre após alterar um modelo.

### 4.3 Cores
Escolha a cor (BLUE, RED, BROWN, GRAY, EMPTY…) ou crie uma nova. Modo **HSV** (gamas mín/máx) ou **RGB**
(cor + distância). O botão do seletor define uma gama a partir de uma cor. Carregue uma fotografia de teste:
os píxeis capturados aparecem a verde **em tempo real**. Guarde.

### 4.4 Tolerâncias
Tolerância de cor, posição e rotação, confiança mínima, margem mínima entre modelos, área mínima da caixa.
Se houver muitos FAIL por luz: aumente a tolerância de cor. Se houver confusões entre modelos parecidos:
aumente a margem mínima e acrescente regiões que os distingam.

### 4.5 Sistema
Exportar/importar configuração (JSON), backup completo (ZIP), limpar histórico antigo, alterar password.
Para copiar a configuração para outra linha: **Exportar** numa e **Importar** na outra.

## 5. Problemas frequentes
| Sintoma | Ação |
|---|---|
| "Fuse Box não detetada" | Melhorar fundo/contraste, aproximar a câmara; reduzir "Área mínima" nas Tolerâncias |
| Região lida como UNKNOWN | Ajustar a cor em **Cores** com a fotografia de teste |
| Dois modelos muito próximos | Acrescentar regiões distintivas; subir margem mínima |
| Esqueci a password | Peça ao administrador (ver Manual Técnico, §7) |

## 6. Se o resultado der FAIL com confiança alta
Leia a caixa vermelha por cima do resultado: indica sempre o motivo. Casos típicos:
- **Ambiguidade entre dois modelos**: ambos chegam a 100 % porque as regiões não os distinguem. Acrescente regiões
  nas posições onde diferem. (Se um modelo tem só um subconjunto das regiões do outro, vence o que tem mais regiões.)
- **Confiança abaixo do mínimo**: reveja as cores ou baixe a confiança mínima nas Tolerâncias.
- **Imagens de referência antigas**: se as regiões não coincidem com a produção, volte a carregar a fotografia de
  referência (botão **Imagem** no modelo) e confirme as regiões no Editor.

## 7. Aceitar menos de 100 %
Não é preciso 100 % para dar PASS. A confiança mínima é ajustável:
- **Global**: Engenharia → Tolerâncias → *Confiança mínima* (arraste ou escreva o valor, ex.: 80).
- **Por modelo**: Engenharia → Modelos → editar → *Confiança mínima deste modelo* (vazio = usa a global).
O resultado mostra "Confiança mínima exigida". Atenção à *Margem mínima* (Tolerâncias): com mínimos baixos,
dois modelos com scores próximos podem dar FAIL por ambiguidade; reduza a margem se pretender aceitar esses casos.

## 8. Modelos que se confundem (ex.: AS e AT)
Quando a caixa de um modelo está contida em caixas maiores de outro, ambos leem a cor certa e dão 100 %.
Três ferramentas no **Editor de regiões** (use *Testar com fotografia* e abra "ver regiões deste modelo" para ver as percentagens):
1. **Tolerância da região (cobertura mínima)**: suba para 90–95 % nas regiões desses modelos. Só aceita se a região
   estiver quase toda da cor esperada. Resolve quando a região do AT também apanha espaço que no AS não tem a cor.
2. **Exigir contorno diferente (caixa isolada)**: liga-se por região. O sistema olha para um anel à volta da região
   (tracejado no editor) e exige que ali a cor esperada **não** continue (máx. por defeito 25 %). Resolve quando a caixa
   do AT está dentro de caixas maiores do AS: no AS o contorno também é azul e o AT falha; no AT o contorno é escuro e passa.
3. **Regiões de exclusão**: acrescente ao modelo regiões onde o outro tem cor e este deve ter outra (ex.: EMPTY).

## 9. Conta-gotas (Cores)
Em Engenharia → Cores, carregue uma fotografia de teste: por baixo da pré-visualização aparece o **Conta-gotas**.
- **Clique** num ponto: mostra HEX, RGB, HSL e HSV (escala OpenCV) desse pixel.
- **Arraste** uma zona (ex.: um relé inteiro): mostra a mediana e a gama p5–p95 de H, S e V. O botão *Aplicar gama* copia essa
  gama para a cor em edição (com uma pequena margem). Repita com 2–3 fotos de luz diferente e guarde.
Um pixel isolado varia com ruído e reflexos; para definir uma cor use sempre uma zona.

## 10. Castanho (ou outra cor) que não é reconhecida
Veja a coluna **Lido** do resultado: por baixo da cor lida aparecem as percentagens por cor na região (ex.: `RED 70% · BROWN 30%`).
- Causa mais comum: as gamas de duas cores **se sobrepõem** (o castanho do relé também cai na gama do vermelho) ou a gama
  não cobre a matiz real (o castanho destes relés é H 2–5, mais perto do vermelho que do laranja).
- Solução: Engenharia → Cores → carregue uma foto → no **Conta-gotas** arraste sobre o relé castanho → *Aplicar gama a BROWN*;
  repita no relé vermelho com a cor RED. Cada cor fica com um **centro medido**, e quando duas gamas se sobrepõem cada píxel
  vai para a cor com o centro mais próximo. Guarde e use *Testar com fotografia*.
