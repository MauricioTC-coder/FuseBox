import { useEffect, useState } from 'react';
import { AppBar, Box, Button, Container, CssBaseline, ThemeProvider, Toolbar, Typography, createTheme } from '@mui/material';
import { NavLink, Navigate, Route, Routes } from 'react-router-dom';
import Identify from './pages/Identify.jsx';
import History from './pages/History.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Engineering from './pages/Engineering.jsx';

// Tema "chão de fábrica": fundo claro e contrastado (boa leitura sob luz forte), barra de aviso amarela.
const theme = createTheme({
  palette: {
    mode: 'light',
    primary: { main: '#2f3b47' },
    secondary: { main: '#f2b705' },
    success: { main: '#1b8a3a' },
    error: { main: '#c62828' },
    background: { default: '#eef0ec', paper: '#ffffff' },
  },
  shape: { borderRadius: 6 },
  typography: {
    fontFamily: '"Segoe UI", "Helvetica Neue", Arial, sans-serif',
    button: { textTransform: 'none', fontWeight: 600 },
  },
});

const links = [['/', 'Identificar'], ['/historico', 'Histórico'], ['/dashboard', 'Dashboard'], ['/engenharia', 'Engenharia']];

export default function App() {
  const [version, setVersion] = useState('');
  useEffect(() => { fetch('/api/health').then((r) => r.json()).then((d) => setVersion(d.version || '')).catch(() => {}); }, []);
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <AppBar position="sticky" elevation={0} sx={{ borderBottom: '6px solid #f2b705' }}>
        <Toolbar sx={{ gap: 1, flexWrap: 'wrap' }}>
          <Typography variant="h6" sx={{ fontWeight: 800, mr: 3, letterSpacing: 0.5 }}>FuseBox ID</Typography>
          {links.map(([to, label]) => (
            <Button key={to} component={NavLink} to={to} end={to === '/'} color="inherit"
              sx={{ '&.active': { bgcolor: 'rgba(255,255,255,.16)' } }}>{label}</Button>
          ))}
        </Toolbar>
      </AppBar>
      <Container maxWidth="xl" sx={{ py: 3 }}>
        <Routes>
          <Route path="/" element={<Identify />} />
          <Route path="/historico" element={<History />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/engenharia" element={<Engineering />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </Container>
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', textAlign: 'center', pb: 2 }}>FuseBox ID v{version || '?'}</Typography>
    </ThemeProvider>
  );
}
