// Cliente da API REST. O token de engenharia fica em sessionStorage (expira ao fechar o separador).
const BASE = '/api';
export const getToken = () => sessionStorage.getItem('eng_token');
export const setToken = (t) => (t ? sessionStorage.setItem('eng_token', t) : sessionStorage.removeItem('eng_token'));

async function request(path, { method = 'GET', json, form, blob = false } = {}) {
  const headers = {};
  let body;
  if (json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(json); }
  if (form) body = form;
  const t = getToken();
  if (t) headers['X-Eng-Token'] = t;
  const res = await fetch(BASE + path, { method, headers, body });
  if (!res.ok) {
    let msg = res.statusText;
    try { const j = await res.json(); msg = typeof j.detail === 'string' ? j.detail : JSON.stringify(j.detail); } catch { /* sem corpo */ }
    if (res.status === 401 && t) { setToken(null); window.dispatchEvent(new Event('eng-logout')); }
    throw new Error(msg);
  }
  if (blob) return res.blob();
  return res.status === 204 ? null : res.json();
}

const qs = (o) => new URLSearchParams(Object.entries(o).filter(([, v]) => v !== '' && v != null)).toString();

export function downloadBlob(blob, filename) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

export const api = {
  login: (password) => request('/auth/login', { method: 'POST', json: { password } }),
  checkAuth: () => request('/auth/check'),
  changePassword: (old_password, new_password) => request('/auth/password', { method: 'POST', json: { old_password, new_password } }),
  models: () => request('/models'),
  layout: (id) => request(`/layouts/${id}`),
  createModel: (m) => request('/models', { method: 'POST', json: m }),
  updateModel: (id, m) => request(`/models/${id}`, { method: 'PUT', json: m }),
  deleteModel: (id) => request(`/models/${id}`, { method: 'DELETE' }),
  addLayout: (mid, name, file, autoCrop) => {
    const f = new FormData(); f.append('name', name); f.append('image', file); f.append('auto_crop', autoCrop);
    return request(`/models/${mid}/layouts`, { method: 'POST', form: f });
  },
  replaceImage: (lid, file, autoCrop) => {
    const f = new FormData(); f.append('image', file); f.append('auto_crop', autoCrop);
    return request(`/layouts/${lid}/image`, { method: 'POST', form: f });
  },
  updateLayout: (id, l) => request(`/layouts/${id}`, { method: 'PUT', json: l }),
  deleteLayout: (id) => request(`/layouts/${id}`, { method: 'DELETE' }),
  saveRegions: (id, regions) => request(`/layouts/${id}/regions`, { method: 'PUT', json: { regions } }),
  colors: () => request('/colors'),
  saveColor: (name, cfg) => request(`/colors/${encodeURIComponent(name)}`, { method: 'PUT', json: cfg }),
  deleteColor: (name) => request(`/colors/${encodeURIComponent(name)}`, { method: 'DELETE' }),
  colorPreview: async (file, cfg, tolerance) => {
    const f = new FormData(); f.append('image', file); f.append('config', JSON.stringify(cfg)); f.append('tolerance', tolerance);
    return URL.createObjectURL(await request('/colors/preview', { method: 'POST', form: f, blob: true }));
  },
  settings: () => request('/settings'),
  saveSettings: (v) => request('/settings', { method: 'PUT', json: v }),
  identify: (file, operator, dryRun = false) => {
    const f = new FormData(); f.append('image', file); f.append('operator', operator); f.append('dry_run', dryRun);
    return request('/identify', { method: 'POST', form: f });
  },
  history: (p) => request(`/history?${qs(p)}`),
  historyItem: (id) => request(`/history/${id}`),
  dashboard: (days) => request(`/dashboard?days=${days}`),
  exportConfig: () => request('/config/export', { blob: true }),
  importConfig: (data, replace) => request(`/config/import?replace=${replace}`, { method: 'POST', json: data }),
  backup: () => request('/backup', { blob: true }),
  purgeHistory: (days) => request('/history/purge', { method: 'POST', json: { days } }),
};
