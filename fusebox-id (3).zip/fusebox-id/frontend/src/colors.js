// Conversões de cor (escala HSV do OpenCV: H 0-179, S/V 0-255) para pré-visualização na interface.
const hex2 = (n) => Math.round(Math.max(0, Math.min(255, n))).toString(16).padStart(2, '0');

export function hsvToHex(h, s, v) {
  const H = (h * 2) % 360, S = s / 255, V = v / 255;
  const c = V * S, x = c * (1 - Math.abs(((H / 60) % 2) - 1)), m = V - c;
  const [r, g, b] = H < 60 ? [c, x, 0] : H < 120 ? [x, c, 0] : H < 180 ? [0, c, x] : H < 240 ? [0, x, c] : H < 300 ? [x, 0, c] : [c, 0, x];
  return '#' + hex2((r + m) * 255) + hex2((g + m) * 255) + hex2((b + m) * 255);
}

export function hexToRgb(hex) {
  const n = parseInt(hex.slice(1), 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

export const rgbToHex = (r, g, b) => '#' + hex2(r) + hex2(g) + hex2(b);

export function rgbToHsv(r, g, b) {
  const R = r / 255, G = g / 255, B = b / 255, mx = Math.max(R, G, B), mn = Math.min(R, G, B), d = mx - mn;
  let h = 0;
  if (d) h = mx === R ? ((G - B) / d) % 6 : mx === G ? (B - R) / d + 2 : (R - G) / d + 4;
  h = (h * 60 + 360) % 360;
  return { h: Math.round(h / 2) % 180, s: Math.round(mx ? (d / mx) * 255 : 0), v: Math.round(mx * 255) };
}

// Cor representativa (centro da gama) de uma definição de cor.
export function colorCss(cfg) {
  if (!cfg) return '#888888';
  const p = cfg.params;
  if (cfg.mode === 'rgb') return rgbToHex(p.r, p.g, p.b);
  const hMax = p.h_max >= p.h_min ? p.h_max : p.h_max + 180;
  return hsvToHex(((p.h_min + hMax) / 2) % 180, (p.s_min + p.s_max) / 2, (p.v_min + p.v_max) / 2);
}

export const DEFAULT_HSV = { h_min: 0, h_max: 179, s_min: 0, s_max: 255, v_min: 0, v_max: 255 };
export const DEFAULT_RGB = { r: 128, g: 128, b: 128, distance: 60 };
