import { useEffect, useRef, useState } from 'react';
import { Alert, Box, Button, Paper, Stack, Typography } from '@mui/material';
import { rgbToHex, rgbToHsv } from '../colors.js';

// Conta-gotas: clique = cor exata de 1 ponto (HEX / RGB / HSL / HSV OpenCV);
// arrastar = estatística de uma zona (mediana e gama p5–p95) e botão para aplicar essa gama à cor em edição.
const pct = (arr, p) => { const a = [...arr].sort((x, y) => x - y); return a[Math.min(a.length - 1, Math.max(0, Math.round((p / 100) * (a.length - 1))))]; };

function rgbToHsl(r, g, b) {
  const R = r / 255, G = g / 255, B = b / 255, mx = Math.max(R, G, B), mn = Math.min(R, G, B), l = (mx + mn) / 2, d = mx - mn;
  let h = 0, s = 0;
  if (d) {
    s = d / (1 - Math.abs(2 * l - 1));
    h = mx === R ? ((G - B) / d) % 6 : mx === G ? (B - R) / d + 2 : (R - G) / d + 4;
    h = (h * 60 + 360) % 360;
  }
  return `hsl(${Math.round(h)}°, ${Math.round(s * 100)}%, ${Math.round(l * 100)}%)`;
}

function analyse(data) {
  const n = data.length / 4, hs = [], ss = [], vs = [], rs = [], gs = [], bs = [];
  for (let i = 0; i < data.length; i += 4) {
    const { h, s, v } = rgbToHsv(data[i], data[i + 1], data[i + 2]);
    hs.push(h); ss.push(s); vs.push(v); rs.push(data[i]); gs.push(data[i + 1]); bs.push(data[i + 2]);
  }
  // matiz circular (vermelho atravessa 0): se há pixéis nos dois extremos, calcula num eixo deslocado
  const low = hs.filter((h) => h < 30).length, high = hs.filter((h) => h > 150).length;
  const wrap = low > n * 0.05 && high > n * 0.05;
  const hh = wrap ? hs.map((h) => (h + 90) % 180) : hs;
  const back = (h) => (wrap ? (h + 90) % 180 : h);
  return {
    n, wrap,
    rgb: [pct(rs, 50), pct(gs, 50), pct(bs, 50)],
    hsv: { h: back(pct(hh, 50)), s: pct(ss, 50), v: pct(vs, 50) },
    range: { h_min: back(pct(hh, 5)), h_max: back(pct(hh, 95)), s_min: pct(ss, 5), s_max: pct(ss, 95), v_min: pct(vs, 5), v_max: pct(vs, 95) },
    dist: (() => { const m = [pct(rs, 50), pct(gs, 50), pct(bs, 50)]; return pct(rs.map((r, i) => Math.hypot(r - m[0], gs[i] - m[1], bs[i] - m[2])), 95); })(),
  };
}

export default function Eyedropper({ file, mode, onApply, colorName }) {
  const canvas = useRef(null), imgRef = useRef(null), drag = useRef(null);
  const [res, setRes] = useState(null);
  const [ready, setReady] = useState(0);

  useEffect(() => {
    if (!file) return undefined;
    const url = URL.createObjectURL(file);
    const im = new Image();
    im.onload = () => {
      const s = Math.min(1, 1000 / Math.max(im.naturalWidth, im.naturalHeight));
      const c = canvas.current; c.width = Math.round(im.naturalWidth * s); c.height = Math.round(im.naturalHeight * s);
      c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); imgRef.current = im; setRes(null); setReady((n) => n + 1);
    };
    im.src = url;
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const pos = (e) => { const b = canvas.current.getBoundingClientRect(); return { x: Math.round(((e.clientX - b.left) / b.width) * canvas.current.width), y: Math.round(((e.clientY - b.top) / b.height) * canvas.current.height) }; };
  const redraw = (rect) => {
    const c = canvas.current, ctx = c.getContext('2d');
    ctx.drawImage(imgRef.current, 0, 0, c.width, c.height);
    if (!rect) return;
    ctx.lineWidth = 3; ctx.strokeStyle = '#000'; ctx.strokeRect(rect.x - 1, rect.y - 1, rect.w + 2, rect.h + 2);
    ctx.lineWidth = 1.5; ctx.strokeStyle = '#fff'; ctx.strokeRect(rect.x, rect.y, rect.w, rect.h);
  };
  const down = (e) => { canvas.current.setPointerCapture(e.pointerId); drag.current = pos(e); };
  const move = (e) => {
    if (!drag.current) return;
    const p = pos(e), s = drag.current;
    redraw({ x: Math.min(s.x, p.x), y: Math.min(s.y, p.y), w: Math.abs(p.x - s.x), h: Math.abs(p.y - s.y) });
  };
  const up = (e) => {
    const s = drag.current, p = pos(e); drag.current = null;
    if (!s) return;
    const x = Math.min(s.x, p.x), y = Math.min(s.y, p.y), w = Math.abs(p.x - s.x), h = Math.abs(p.y - s.y);
    const ctx = canvas.current.getContext('2d');
    if (w < 3 && h < 3) {  // clique: 1 ponto
      redraw({ x: p.x - 4, y: p.y - 4, w: 8, h: 8 });
      const d = ctx.getImageData(p.x, p.y, 1, 1).data;
      setRes({ point: true, ...analyse(d) });
    } else { redraw({ x, y, w, h }); setRes({ point: false, ...analyse(ctx.getImageData(x, y, w, h).data) }); }
  };

  if (!file) return null;
  const hex = res ? rgbToHex(...res.rgb) : '#000';
  const apply = () => {
    if (mode === 'rgb') return onApply({ r: res.rgb[0], g: res.rgb[1], b: res.rgb[2], distance: Math.min(442, Math.round(res.dist + 10)) });
    const r = res.range, m = 3, sv = 10;
    onApply({ c_h: res.hsv.h, c_s: res.hsv.s, c_v: res.hsv.v, h_min: (r.h_min - m + 180) % 180, h_max: (r.h_max + m) % 180, s_min: Math.max(0, r.s_min - sv), s_max: Math.min(255, r.s_max + sv), v_min: Math.max(0, r.v_min - sv), v_max: Math.min(255, r.v_max + sv) });
  };

  return (
    <Paper sx={{ p: 2, mt: 2 }}>
      <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1 }}>Conta-gotas</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
        <b>Clique</b> para ler a cor exata de um ponto. <b>Arraste</b> uma zona (ex.: o relé todo) para obter a mediana e a gama de cor, e aplique-a à cor em edição.
      </Typography>
      <canvas ref={canvas} onPointerDown={down} onPointerMove={move} onPointerUp={up}
        style={{ width: '100%', display: 'block', cursor: 'crosshair', touchAction: 'none', borderRadius: 4 }} />
      {res && (
        <Stack direction="row" spacing={2} sx={{ mt: 2 }} alignItems="flex-start" flexWrap="wrap" useFlexGap>
          <Box sx={{ width: 72, height: 72, bgcolor: hex, border: '2px solid #000', borderRadius: 1 }} />
          <Box sx={{ fontFamily: 'monospace', fontSize: 14, lineHeight: 1.7 }}>
            <div>{res.point ? 'Ponto' : `Zona (${res.n} píxeis, mediana)`}</div>
            <div>HEX {hex.toUpperCase()}</div>
            <div>RGB {res.rgb.join(', ')}</div>
            <div>{rgbToHsl(...res.rgb)}</div>
            <div>HSV (OpenCV) H {res.hsv.h} · S {res.hsv.s} · V {res.hsv.v}</div>
            {!res.point && <div>Gama p5–p95: H {res.range.h_min}–{res.range.h_max}{res.wrap ? ' (atravessa 0)' : ''} · S {res.range.s_min}–{res.range.s_max} · V {res.range.v_min}–{res.range.v_max}</div>}
          </Box>
          {!res.point && <Button variant="contained" color="secondary" onClick={apply} sx={{ color: '#1c2024' }}>Aplicar gama a {colorName}</Button>}
        </Stack>
      )}
      {res?.point && <Alert severity="info" sx={{ mt: 1 }}>Um só pixel varia com ruído e reflexos. Para definir uma cor, arraste uma zona inteira.</Alert>}
    </Paper>
  );
}
