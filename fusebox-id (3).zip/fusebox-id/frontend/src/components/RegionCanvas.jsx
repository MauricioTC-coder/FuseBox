import { useEffect, useRef, useState } from 'react';

// Editor visual: desenhar (arrastar em zona vazia), mover (arrastar dentro), redimensionar (cantos).
// Coordenadas das regiões normalizadas 0-1 relativamente à imagem alinhada.
const HANDLE_PX = 12;
const clamp = (v) => Math.max(0, Math.min(1, v));

export default function RegionCanvas({ imageUrl, regions, setRegions, selected, setSelected, colorHex, makeRegion }) {
  const canvasRef = useRef(null);
  const imgRef = useRef(null);
  const drag = useRef(null);
  const [ready, setReady] = useState(0);

  useEffect(() => {
    const im = new Image();
    im.onload = () => { imgRef.current = im; setReady((n) => n + 1); };
    im.src = imageUrl;
  }, [imageUrl]);

  useEffect(() => {
    const im = imgRef.current, c = canvasRef.current;
    if (!im || !c) return;
    c.width = im.naturalWidth; c.height = im.naturalHeight;
    const ctx = c.getContext('2d');
    ctx.drawImage(im, 0, 0);
    ctx.font = '14px sans-serif';
    regions.forEach((r, i) => {
      const x = r.x * c.width, y = r.y * c.height, w = r.w * c.width, h = r.h * c.height;
      const col = colorHex(r.color);
      ctx.fillStyle = col + '40'; ctx.fillRect(x, y, w, h);
      ctx.lineWidth = i === selected ? 5 : 3; ctx.strokeStyle = '#000'; ctx.strokeRect(x, y, w, h);
      ctx.lineWidth = i === selected ? 3 : 1.5; ctx.strokeStyle = i === selected ? '#f2b705' : col; ctx.strokeRect(x, y, w, h);
      ctx.fillStyle = '#000'; ctx.fillText(r.name, x + 4, y + 16); ctx.fillStyle = '#fff'; ctx.fillText(r.name, x + 3, y + 15);
      if (i === selected && r.ring_margin > 0) {  // contorno a verificar
        const mx = w * r.ring_margin / 100, my = h * r.ring_margin / 100;
        ctx.setLineDash([6, 4]); ctx.lineWidth = 2; ctx.strokeStyle = '#ffffff';
        ctx.strokeRect(x - mx, y - my, w + 2 * mx, h + 2 * my); ctx.setLineDash([]);
      }
      if (i === selected) {
        ctx.fillStyle = '#f2b705';
        [[x, y], [x + w, y], [x, y + h], [x + w, y + h]].forEach(([hx, hy]) => ctx.fillRect(hx - 6, hy - 6, 12, 12));
      }
    });
  }, [regions, selected, ready, colorHex]);

  const point = (e) => {
    const b = canvasRef.current.getBoundingClientRect();
    return { x: clamp((e.clientX - b.left) / b.width), y: clamp((e.clientY - b.top) / b.height), bw: b.width, bh: b.height };
  };

  const down = (e) => {
    const p = point(e);
    canvasRef.current.setPointerCapture(e.pointerId);
    if (selected != null && regions[selected]) {
      const r = regions[selected];
      const corners = [[r.x, r.y], [r.x + r.w, r.y], [r.x, r.y + r.h], [r.x + r.w, r.y + r.h]];
      const k = corners.findIndex(([cx, cy]) => Math.abs(cx - p.x) * p.bw < HANDLE_PX && Math.abs(cy - p.y) * p.bh < HANDLE_PX);
      if (k >= 0) { drag.current = { type: 'resize', idx: selected, fx: k % 2 === 0 ? r.x + r.w : r.x, fy: k < 2 ? r.y + r.h : r.y }; return; }
    }
    for (let i = regions.length - 1; i >= 0; i--) {
      const r = regions[i];
      if (p.x >= r.x && p.x <= r.x + r.w && p.y >= r.y && p.y <= r.y + r.h) {
        setSelected(i); drag.current = { type: 'move', idx: i, sx: p.x, sy: p.y, orig: { ...r } }; return;
      }
    }
    const idx = regions.length;
    setRegions([...regions, makeRegion(regions, p.x, p.y)]);
    setSelected(idx);
    drag.current = { type: 'new', idx, fx: p.x, fy: p.y };
  };

  const move = (e) => {
    const d = drag.current;
    if (!d) return;
    const p = point(e);
    setRegions((prev) => prev.map((r, i) => {
      if (i !== d.idx) return r;
      if (d.type === 'move') {
        return { ...r, x: clamp(Math.min(d.orig.x + p.x - d.sx, 1 - r.w)), y: clamp(Math.min(d.orig.y + p.y - d.sy, 1 - r.h)) };
      }
      return { ...r, x: Math.min(d.fx, p.x), y: Math.min(d.fy, p.y), w: Math.abs(p.x - d.fx), h: Math.abs(p.y - d.fy) };
    }));
  };

  const up = () => {
    const d = drag.current;
    drag.current = null;
    if (d && (d.type === 'new' || d.type === 'resize')) {
      setRegions((prev) => {
        const r = prev[d.idx];
        if (r && (r.w < 0.01 || r.h < 0.01)) { setSelected(null); return d.type === 'new' ? prev.filter((_, i) => i !== d.idx) : prev; }
        return prev;
      });
    }
  };

  return (
    <canvas ref={canvasRef} onPointerDown={down} onPointerMove={move} onPointerUp={up}
      style={{ width: '100%', maxWidth: 960, display: 'block', touchAction: 'none', cursor: 'crosshair', borderRadius: 4, background: '#cfd3cc' }} />
  );
}
