import { Alert, Box, Chip, Grid, LinearProgress, Paper, Table, TableBody, TableCell, TableHead, TableRow, Typography } from '@mui/material';

// Resultado de uma identificação: estado, modelo, confiança, regiões, ranking e imagem anotada.
export default function ResultView({ result }) {
  const pass = result.status === 'PASS';
  const img = result.annotated_b64 ? `data:image/jpeg;base64,${result.annotated_b64}` : `/api/history/${result.id}/annotated`;
  return (
    <Grid container spacing={2}>
      <Grid item xs={12} md={5}>
        <Paper sx={{ p: 3, borderLeft: `12px solid ${pass ? '#1b8a3a' : '#c62828'}` }}>
          <Typography color="text.secondary">Modelo detetado</Typography>
          <Typography sx={{ fontSize: 56, fontWeight: 800, lineHeight: 1.1 }}>{result.model_code}</Typography>
          <Typography color="text.secondary">{result.model_name}</Typography>
          <Box sx={{ display: 'flex', gap: 3, my: 2, alignItems: 'baseline' }}>
            <Box>
              <Typography color="text.secondary" variant="body2">Confiança</Typography>
              <Typography variant="h4" sx={{ fontVariantNumeric: 'tabular-nums' }}>{result.confidence.toFixed(1)}%</Typography>
            </Box>
            <Chip label={result.status} color={pass ? 'success' : 'error'} sx={{ fontSize: 22, fontWeight: 800, height: 48, px: 2 }} />
          </Box>
          {result.angle !== undefined && <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>Alinhamento: {result.alignment === 'anchors' ? 'por âncoras' : 'por contorno'} · rotação {result.angle}° · {result.box_found ? 'caixa detetada' : 'caixa não detetada (imagem inteira)'}</Typography>}
          {result.min_confidence_used != null && <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>Confiança mínima exigida: {result.min_confidence_used}%</Typography>}
          {result.reasons.map((r) => <Alert key={r} severity="error" sx={{ mb: 1 }}>{r}</Alert>)}
          {(result.warnings || []).map((w) => <Alert key={w} severity="info" sx={{ mb: 1 }}>{w}</Alert>)}
          <Typography variant="subtitle2" sx={{ mt: 2, mb: 1 }}>Comparação com os modelos</Typography>
          {result.ranking.map((r) => (
            <Box key={r.model_code} sx={{ mb: 1 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Typography variant="body2" sx={{ fontWeight: r.model_code === result.model_code ? 700 : 400 }}>{r.model_code}</Typography>
                <Typography variant="body2" sx={{ fontVariantNumeric: 'tabular-nums' }}>{r.score.toFixed(1)}%{r.matched != null ? ` (${r.matched}/${r.total})` : ''}</Typography>
              </Box>
              <LinearProgress variant="determinate" value={r.score} color={r.model_code === result.model_code ? 'secondary' : 'inherit'} />
              {r.regions && (
                <details>
                  <summary style={{ cursor: 'pointer', fontSize: 12, color: '#666' }}>ver regiões deste modelo</summary>
                  <Typography variant="caption" component="div">
                    {r.regions.map((g) => `${g.name}: ${g.expected}→${g.detected} ${g.fraction}%${g.ring != null ? ` / contorno ${g.ring}%` : ''} ${g.match ? '✔' : '✘'}`).join('  ·  ')}
                  </Typography>
                </details>
              )}
            </Box>
          ))}
        </Paper>
      </Grid>
      <Grid item xs={12} md={7}>
        <Paper sx={{ p: 2 }}>
          <img src={img} alt="Fuse Box alinhada com regiões" style={{ width: '100%', display: 'block', borderRadius: 4 }} />
          <Table size="small" sx={{ mt: 2 }}>
            <TableHead><TableRow><TableCell>Região</TableCell><TableCell>Esperado</TableCell><TableCell>Lido</TableCell><TableCell align="right">Cobertura</TableCell><TableCell align="right">Contorno</TableCell><TableCell>OK</TableCell></TableRow></TableHead>
            <TableBody>
              {result.regions.map((r) => (
                <TableRow key={r.name} sx={{ bgcolor: r.match ? 'transparent' : '#fdecea' }}>
                  <TableCell>{r.name}</TableCell><TableCell>{r.expected}</TableCell><TableCell>{r.detected}{r.reads && Object.keys(r.reads).length > 0 && <Typography variant="caption" component="div" color="text.secondary">{Object.entries(r.reads).map(([k, v]) => `${k} ${v}%`).join(' · ')}</Typography>}</TableCell>
                  <TableCell align="right">{r.fraction}%</TableCell><TableCell align="right">{r.ring != null ? `${r.ring}%` : '—'}</TableCell><TableCell>{r.match ? '✔' : '✘'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Paper>
      </Grid>
    </Grid>
  );
}
