import { useEffect, useRef, useState } from 'react';
import { Alert, Button, Dialog, DialogActions, DialogContent, DialogTitle } from '@mui/material';

// Captura com webcam (getUserMedia exige HTTPS ou localhost). Devolve um File JPEG.
export default function Webcam({ open, onClose, onCapture }) {
  const video = useRef(null);
  const stream = useRef(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!open) return undefined;
    setError('');
    navigator.mediaDevices?.getUserMedia({ video: { facingMode: 'environment', width: { ideal: 1920 } } })
      .then((s) => { stream.current = s; if (video.current) video.current.srcObject = s; })
      .catch((e) => setError(`Não foi possível aceder à câmara: ${e.message}`));
    return () => { stream.current?.getTracks().forEach((t) => t.stop()); stream.current = null; };
  }, [open]);

  const snap = () => {
    const v = video.current;
    const c = document.createElement('canvas');
    c.width = v.videoWidth; c.height = v.videoHeight;
    c.getContext('2d').drawImage(v, 0, 0);
    c.toBlob((b) => { onCapture(new File([b], 'captura.jpg', { type: 'image/jpeg' })); onClose(); }, 'image/jpeg', 0.92);
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>Câmara</DialogTitle>
      <DialogContent>
        {error ? <Alert severity="error">{error}</Alert> : <video ref={video} autoPlay playsInline muted style={{ width: '100%', background: '#000' }} />}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancelar</Button>
        <Button variant="contained" color="secondary" disabled={!!error} onClick={snap}>Capturar</Button>
      </DialogActions>
    </Dialog>
  );
}
