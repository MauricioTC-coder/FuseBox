import { useState } from 'react';
import { Alert, Button, FormControlLabel, Paper, Stack, Switch, TextField, Typography } from '@mui/material';
import { api, downloadBlob } from '../api.js';

export default function Admin() {
  const [msg, setMsg] = useState(null);
  const [replace, setReplace] = useState(false);
  const [pw, setPw] = useState({ old: '', next: '' });
  const [days, setDays] = useState(365);
  const run = async (fn, ok) => {
    try { const r = await fn(); setMsg({ s: 'success', t: typeof ok === 'function' ? ok(r) : ok }); }
    catch (e) { setMsg({ s: 'error', t: e.message }); }
  };
  const stamp = new Date().toISOString().slice(0, 10);
  const doImport = (e) => {
    const f = e.target.files[0]; e.target.value = '';
    if (!f) return;
    if (replace && !window.confirm('Substituir TODOS os modelos e cores pelo conteúdo do ficheiro?')) return;
    run(async () => api.importConfig(JSON.parse(await f.text()), replace), (r) => `Importados ${r.models} modelos e ${r.colors} cores.`);
  };

  return (
    <Stack spacing={2}>
      <Typography variant="h5" sx={{ fontWeight: 700 }}>Sistema</Typography>
      {msg && <Alert severity={msg.s} onClose={() => setMsg(null)}>{msg.t}</Alert>}
      <Paper sx={{ p: 3 }}>
        <Typography variant="h6" sx={{ mb: 1 }}>Configuração (modelos, regiões, cores, tolerâncias)</Typography>
        <Stack direction="row" spacing={2} alignItems="center" flexWrap="wrap" useFlexGap>
          <Button variant="contained" onClick={() => run(async () => downloadBlob(await api.exportConfig(), `fusebox-config-${stamp}.json`), 'Configuração exportada.')}>Exportar</Button>
          <Button component="label" variant="outlined">Importar ficheiro…<input type="file" accept="application/json" hidden onChange={doImport} /></Button>
          <FormControlLabel control={<Switch checked={replace} onChange={(e) => setReplace(e.target.checked)} />} label="Substituir tudo (em vez de juntar por código de modelo)" />
        </Stack>
      </Paper>
      <Paper sx={{ p: 3 }}>
        <Typography variant="h6" sx={{ mb: 1 }}>Backup completo</Typography>
        <Typography variant="body2" sx={{ mb: 1 }}>ZIP com a base de dados (incluindo histórico) e todas as imagens.</Typography>
        <Button variant="contained" onClick={() => run(async () => downloadBlob(await api.backup(), `fusebox-backup-${stamp}.zip`), 'Backup descarregado.')}>Descarregar backup</Button>
      </Paper>
      <Paper sx={{ p: 3 }}>
        <Typography variant="h6" sx={{ mb: 1 }}>Limpar histórico antigo</Typography>
        <Stack direction="row" spacing={2}>
          <TextField type="number" size="small" label="Apagar registos com mais de (dias)" value={days} onChange={(e) => setDays(+e.target.value)} sx={{ width: 280 }} />
          <Button color="error" variant="outlined" onClick={() => window.confirm(`Apagar registos com mais de ${days} dias?`) && run(() => api.purgeHistory(days), (r) => `${r.deleted} registos apagados.`)}>Limpar</Button>
        </Stack>
      </Paper>
      <Paper sx={{ p: 3 }}>
        <Typography variant="h6" sx={{ mb: 1 }}>Alterar password de engenharia</Typography>
        <Stack direction="row" spacing={2}>
          <TextField type="password" size="small" label="Password atual" value={pw.old} onChange={(e) => setPw({ ...pw, old: e.target.value })} />
          <TextField type="password" size="small" label="Nova password (mín. 6)" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} />
          <Button variant="contained" onClick={() => run(() => api.changePassword(pw.old, pw.next), 'Password alterada.').then(() => setPw({ old: '', next: '' }))}>Alterar</Button>
        </Stack>
      </Paper>
    </Stack>
  );
}
