import { useEffect, useRef, useState } from 'react';
import { Alert, Box, Button, Chip, Dialog, DialogActions, DialogContent, DialogTitle, Grid, Paper, Slider, Stack, TextField,
  ToggleButton, ToggleButtonGroup, Typography } from '@mui/material';
import { api } from '../api.js';
import Eyedropper from '../components/Eyedropper.jsx';
import { DEFAULT_HSV, DEFAULT_RGB, colorCss, hexToRgb, hsvToHex, rgbToHex, rgbToHsv } from '../colors.js';

const HSV_FIELDS = [['h', 'Matiz (H)', 179], ['s', 'Saturação (S)', 255], ['v', 'Valor (V)', 255]];

export default function Colors() {
  const [colors, setColors] = useState([]);
  const [sel, setSel] = useState(null);       // nome selecionado
  const [draft, setDraft] = useState(null);   // {name, mode, params}
  const [tol, setTol] = useState(0);
  const [msg, setMsg] = useState(null);
  const [newName, setNewName] = useState(null);
  const [testFile, setTestFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState('');
  const timer = useRef(null);

  const load = (keep) => api.colors().then((cs) => { setColors(cs); if (keep) { const c = cs.find((x) => x.name === keep); if (c) setDraft(structuredClone(c)); } });
  useEffect(() => { load(); api.settings().then((s) => setTol(s.color_tolerance)); }, []);
  const choose = (c) => { setSel(c.name); setDraft(structuredClone(c)); };

  // Pré-visualização em tempo real: reenvia a imagem de teste (com debounce) quando a cor muda.
  useEffect(() => {
    if (!testFile || !draft) return undefined;
    clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      api.colorPreview(testFile, { mode: draft.mode, params: draft.params }, tol).then(setPreviewUrl).catch((e) => setMsg({ s: 'error', t: e.message }));
    }, 350);
    return () => clearTimeout(timer.current);
  }, [testFile, draft, tol]);

  const setParam = (k, v) => setDraft({ ...draft, params: { ...draft.params, [k]: v } });
  const setMode = (mode) => mode && mode !== draft.mode && setDraft({ ...draft, mode, params: mode === 'hsv' ? { ...DEFAULT_HSV } : { ...DEFAULT_RGB } });
  const fromPicker = (hex) => {
    const { r, g, b } = hexToRgb(hex);
    if (draft.mode === 'rgb') return setDraft({ ...draft, params: { ...draft.params, r, g, b } });
    const { h, s, v } = rgbToHsv(r, g, b); // gama HSV em torno da cor escolhida
    const hMin = (h - 10 + 180) % 180, hMax = (h + 10) % 180;
    setDraft({ ...draft, params: { h_min: hMin, h_max: hMax, s_min: Math.max(0, s - 70), s_max: Math.min(255, s + 70), v_min: Math.max(0, v - 70), v_max: Math.min(255, v + 70) } });
  };

  const save = async () => {
    try { await api.saveColor(draft.name, { mode: draft.mode, params: draft.params }); setMsg({ s: 'success', t: `Cor ${draft.name} guardada.` }); load(draft.name); }
    catch (e) { setMsg({ s: 'error', t: e.message }); }
  };
  const del = async () => {
    if (!window.confirm(`Apagar a cor ${draft.name}?`)) return;
    try { await api.deleteColor(draft.name); setDraft(null); setSel(null); load(); setMsg({ s: 'success', t: 'Cor apagada.' }); }
    catch (e) { setMsg({ s: 'error', t: e.message }); }
  };
  const create = () => {
    const name = newName.trim().toUpperCase();
    if (!/^[A-Z0-9_]+$/.test(name)) return setMsg({ s: 'error', t: 'Nome inválido (letras, números e _).' });
    setDraft({ name, mode: 'hsv', params: { ...DEFAULT_HSV } }); setSel(name); setNewName(null);
  };

  const p = draft?.params;
  const hueSteps = draft?.mode === 'hsv'
    ? Array.from({ length: 7 }, (_, i) => {
        const hMax = p.h_max >= p.h_min ? p.h_max : p.h_max + 180;
        return hsvToHex((p.h_min + ((hMax - p.h_min) * i) / 6) % 180, (p.s_min + p.s_max) / 2, (p.v_min + p.v_max) / 2);
      })
    : [];

  return (
    <Stack spacing={2}>
      <Typography variant="h5" sx={{ fontWeight: 700 }}>Cores</Typography>
      {msg && <Alert severity={msg.s} onClose={() => setMsg(null)}>{msg.t}</Alert>}
      <Paper sx={{ p: 2, display: 'flex', gap: 1, flexWrap: 'wrap', alignItems: 'center' }}>
        {colors.map((c) => (
          <Chip key={c.name} label={c.name} onClick={() => choose(c)} variant={sel === c.name ? 'filled' : 'outlined'} color={sel === c.name ? 'secondary' : 'default'}
            avatar={<Box sx={{ bgcolor: colorCss(c), border: '1px solid #000', borderRadius: '50%' }} />} />
        ))}
        <Button onClick={() => setNewName('')}>+ Nova cor</Button>
      </Paper>
      {draft && (
        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <Paper sx={{ p: 2 }}>
              <Stack spacing={2}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                  <Box sx={{ width: 72, height: 72, bgcolor: colorCss(draft), border: '2px solid #000', borderRadius: 1 }} />
                  <Typography variant="h5" sx={{ fontWeight: 800, flex: 1 }}>{draft.name}</Typography>
                  <ToggleButtonGroup exclusive size="small" value={draft.mode} onChange={(_, v) => setMode(v)}>
                    <ToggleButton value="hsv">HSV</ToggleButton><ToggleButton value="rgb">RGB</ToggleButton>
                  </ToggleButtonGroup>
                </Box>
                {draft.mode === 'hsv' && <Box sx={{ display: 'flex', height: 22, border: '1px solid #000' }}>{hueSteps.map((h, i) => <Box key={i} sx={{ flex: 1, bgcolor: h }} />)}</Box>}
                <Button component="label" variant="outlined">Escolher cor com seletor
                  <input type="color" hidden value={colorCss(draft)} onChange={(e) => fromPicker(e.target.value)} /></Button>
                {draft.mode === 'hsv' ? HSV_FIELDS.map(([k, label, max]) => (
                  <Box key={k}>
                    <Typography variant="body2">{label}: mín {p[`${k}_min`]} / máx {p[`${k}_max`]}</Typography>
                    <Slider size="small" min={0} max={max} value={p[`${k}_min`]} onChange={(_, v) => setParam(`${k}_min`, v)} />
                    <Slider size="small" min={0} max={max} value={p[`${k}_max`]} onChange={(_, v) => setParam(`${k}_max`, v)} />
                  </Box>
                )) : (
                  <>
                    {['r', 'g', 'b'].map((k) => (<Box key={k}><Typography variant="body2">{k.toUpperCase()}: {p[k]}</Typography>
                      <Slider size="small" min={0} max={255} value={p[k]} onChange={(_, v) => setParam(k, v)} /></Box>))}
                    <Box><Typography variant="body2">Distância máxima: {p.distance}</Typography>
                      <Slider size="small" min={0} max={442} value={p.distance} onChange={(_, v) => setParam('distance', v)} /></Box>
                  </>
                )}
                {draft.mode === 'hsv' && <Typography variant="caption" color="text.secondary">Escala OpenCV (H 0–179). Se H mín &gt; H máx a gama atravessa 0 (ex.: vermelho). Cor de referência: {rgbToHex(...Object.values(hexToRgb(colorCss(draft))))}.</Typography>}
                {draft.mode === 'hsv' && p.c_h != null && <Typography variant="caption" color="text.secondary">Centro medido: H {p.c_h} · S {p.c_s} · V {p.c_v}. Quando duas cores se sobrepõem, cada píxel vai para a cor com o centro mais próximo.</Typography>}
                <Stack direction="row" spacing={1}><Button variant="contained" onClick={save}>Guardar cor</Button><Button color="error" onClick={del}>Apagar</Button></Stack>
              </Stack>
            </Paper>
          </Grid>
          <Grid item xs={12} md={6}>
            <Paper sx={{ p: 2 }}>
              <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1 }}>Pré-visualização em tempo real</Typography>
              <Button component="label" variant="outlined" sx={{ mb: 1 }}>{testFile ? testFile.name : 'Carregar fotografia de teste'}
                <input type="file" accept="image/*" hidden onChange={(e) => setTestFile(e.target.files[0] || null)} /></Button>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>Os píxeis capturados por esta cor ficam a verde (tolerância de cor atual: {tol}).</Typography>
              {previewUrl ? <img src={previewUrl} alt="Pré-visualização da máscara" style={{ width: '100%', borderRadius: 4 }} /> : <Alert severity="info">Carregue uma fotografia para ver a máscara.</Alert>}
            </Paper>
            <Eyedropper file={testFile} mode={draft.mode} colorName={draft.name} onApply={(params) => setDraft({ ...draft, params })} />
          </Grid>
        </Grid>
      )}
      <Dialog open={newName !== null} onClose={() => setNewName(null)}>
        <DialogTitle>Nova cor</DialogTitle>
        <DialogContent><TextField autoFocus fullWidth sx={{ mt: 1 }} label="Nome (ex.: YELLOW)" value={newName || ''} onChange={(e) => setNewName(e.target.value)} /></DialogContent>
        <DialogActions><Button onClick={() => setNewName(null)}>Cancelar</Button><Button variant="contained" onClick={create}>Criar</Button></DialogActions>
      </Dialog>
    </Stack>
  );
}
