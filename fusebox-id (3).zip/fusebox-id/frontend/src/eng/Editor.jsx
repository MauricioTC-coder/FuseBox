import { useCallback, useEffect, useState } from 'react';
import { Alert, Box, Button, FormControlLabel, Grid, IconButton, MenuItem, Paper, Slider, Stack, Switch, TextField, Typography } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import { api } from '../api.js';
import { colorCss } from '../colors.js';
import RegionCanvas from '../components/RegionCanvas.jsx';
import ResultView from '../components/ResultView.jsx';

export default function Editor({ initialLayoutId }) {
  const [models, setModels] = useState([]);
  const [colors, setColors] = useState([]);
  const [layoutId, setLayoutId] = useState(initialLayoutId || '');
  const [layout, setLayout] = useState(null);
  const [regions, setRegions] = useState([]);
  const [selected, setSelected] = useState(null);
  const [msg, setMsg] = useState(null);
  const [dirty, setDirty] = useState(false);
  const [test, setTest] = useState(null);
  const [stamp, setStamp] = useState(Date.now());

  useEffect(() => { api.models().then(setModels); api.colors().then(setColors); }, []);
  const hexMap = Object.fromEntries(colors.map((c) => [c.name, colorCss(c)]));
  const colorHex = useCallback((n) => hexMap[n] || '#ffffff', [colors]); // eslint-disable-line

  useEffect(() => {
    if (!layoutId) return;
    api.layout(layoutId).then((l) => { setLayout(l); setRegions(l.regions); setSelected(null); setDirty(false); setTest(null); setStamp(Date.now()); })
      .catch((e) => setMsg({ s: 'error', t: e.message }));
  }, [layoutId]);

  const update = (fn) => { setRegions(fn); setDirty(true); };
  const makeRegion = (list, x, y) => {
    let n = list.length + 1;
    while (list.some((r) => r.name === `R${n}`)) n++;
    return { name: `R${n}`, x, y, w: 0, h: 0, color: colors[0]?.name || 'BLUE', tolerance: 60, ring_margin: 0, ring_max: 25 };
  };
  const patch = (i, p) => update((prev) => prev.map((r, k) => (k === i ? { ...r, ...p } : r)));
  const remove = (i) => { update((prev) => prev.filter((_, k) => k !== i)); setSelected(null); };
  const duplicate = (i) => update((prev) => {
    const r = prev[i]; let n = prev.length + 1;
    while (prev.some((q) => q.name === `R${n}`)) n++;
    return [...prev, { ...r, name: `R${n}`, x: Math.min(r.x + 0.02, 1 - r.w), y: Math.min(r.y + 0.02, 1 - r.h) }];
  });

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Delete' && selected != null && !['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName)) remove(selected);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }); // eslint-disable-line

  const save = async () => {
    try { await api.saveRegions(layoutId, regions); setDirty(false); setMsg({ s: 'success', t: `${regions.length} regiões guardadas.` }); }
    catch (e) { setMsg({ s: 'error', t: e.message }); }
  };
  const runTest = async (e) => {
    const f = e.target.files[0]; e.target.value = '';
    if (!f) return;
    try { setTest(await api.identify(f, 'ENGENHARIA', true)); } catch (err) { setMsg({ s: 'error', t: err.message }); }
  };

  return (
    <Stack spacing={2}>
      <Paper sx={{ p: 2, display: 'flex', gap: 2, flexWrap: 'wrap', alignItems: 'center' }}>
        <TextField select size="small" label="Layout" value={layoutId} onChange={(e) => setLayoutId(e.target.value)} sx={{ minWidth: 280 }}>
          {models.flatMap((m) => m.layouts.map((l) => <MenuItem key={l.id} value={l.id}>{m.code} — {l.name}</MenuItem>))}
        </TextField>
        <Button variant="contained" disabled={!layout || !dirty} onClick={save}>Guardar regiões</Button>
        <Button component="label" variant="outlined" disabled={!layout || dirty}>Testar com fotografia
          <input type="file" accept="image/*" hidden onChange={runTest} /></Button>
        {dirty && <Typography color="warning.main">Alterações por guardar</Typography>}
      </Paper>
      {msg && <Alert severity={msg.s} onClose={() => setMsg(null)}>{msg.t}</Alert>}
      {!layout && <Alert severity="info">Escolha um layout. Arraste na imagem para desenhar regiões; arraste dentro para mover; use os cantos para redimensionar; Delete apaga.</Alert>}
      {layout && (
        <Grid container spacing={2}>
          <Grid item xs={12} lg={8}>
            <Paper sx={{ p: 1.5 }}>
              <RegionCanvas imageUrl={`/api/layouts/${layoutId}/image?t=${stamp}`} regions={regions} setRegions={update}
                selected={selected} setSelected={setSelected} colorHex={colorHex} makeRegion={makeRegion} />
            </Paper>
          </Grid>
          <Grid item xs={12} lg={4}>
            <Paper sx={{ p: 1.5, maxHeight: 640, overflow: 'auto' }}>
              <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1 }}>Regiões ({regions.length})</Typography>
              {regions.map((r, i) => (
                <Box key={i} onClick={() => setSelected(i)} sx={{ p: 1, mb: 1, borderRadius: 1, border: '2px solid', borderColor: i === selected ? 'secondary.main' : '#d8dbd4' }}>
                  <Stack direction="row" spacing={1} alignItems="center">
                    <TextField size="small" label="Nome" value={r.name} onChange={(e) => patch(i, { name: e.target.value })} sx={{ width: 90 }} />
                    <TextField select size="small" label="Cor esperada" value={r.color} onChange={(e) => patch(i, { color: e.target.value })} sx={{ flex: 1 }}>
                      {colors.map((c) => (
                        <MenuItem key={c.name} value={c.name}>
                          <Box component="span" sx={{ display: 'inline-block', width: 14, height: 14, bgcolor: colorHex(c.name), border: '1px solid #000', mr: 1, verticalAlign: 'middle' }} />{c.name}
                        </MenuItem>
                      ))}
                    </TextField>
                    <IconButton size="small" aria-label="Duplicar" onClick={() => duplicate(i)}><ContentCopyIcon fontSize="small" /></IconButton>
                    <IconButton size="small" aria-label="Apagar região" onClick={() => remove(i)}><DeleteIcon fontSize="small" /></IconButton>
                  </Stack>
                  <Typography variant="caption">Tolerância (cobertura mínima): {r.tolerance}%</Typography>
                  <Slider size="small" min={1} max={100} value={r.tolerance} onChange={(_, v) => patch(i, { tolerance: v })} />
                  <FormControlLabel control={<Switch size="small" checked={r.ring_margin > 0} onChange={(e) => patch(i, { ring_margin: e.target.checked ? 40 : 0 })} />}
                    label={<Typography variant="body2">Exigir contorno diferente (caixa isolada)</Typography>} />
                  {r.ring_margin > 0 && (
                    <>
                      <Typography variant="caption">Largura do contorno: {r.ring_margin}% da região (linha tracejada)</Typography>
                      <Slider size="small" min={5} max={200} value={r.ring_margin} onChange={(_, v) => patch(i, { ring_margin: v })} />
                      <Typography variant="caption">Máx. de cor esperada no contorno: {r.ring_max}%</Typography>
                      <Slider size="small" min={0} max={100} value={r.ring_max} onChange={(_, v) => patch(i, { ring_max: v })} />
                    </>
                  )}
                </Box>
              ))}
            </Paper>
          </Grid>
        </Grid>
      )}
      {test && <Box><Typography variant="h6" sx={{ mb: 1 }}>Resultado do teste (não gravado no histórico)</Typography><ResultView result={test} /></Box>}
    </Stack>
  );
}
