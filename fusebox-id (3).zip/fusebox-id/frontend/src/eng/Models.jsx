import { useCallback, useEffect, useRef, useState } from 'react';
import { Alert, Box, Button, Chip, Dialog, DialogActions, DialogContent, DialogTitle, FormControlLabel, IconButton, Paper,
  Stack, Switch, TextField, Typography } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import { api } from '../api.js';

const EMPTY = { code: '', name: '', description: '', active: true, min_confidence: '' };

export default function Models({ onEditLayout }) {
  const [models, setModels] = useState([]);
  const [msg, setMsg] = useState(null);
  const [dlg, setDlg] = useState(null);          // modelo em edição/criação
  const [layoutDlg, setLayoutDlg] = useState(null); // {model} ao adicionar layout
  const [file, setFile] = useState(null);
  const [lname, setLname] = useState('Layout 1');
  const replaceInput = useRef(null);
  const replaceId = useRef(null);

  const load = useCallback(() => api.models().then(setModels).catch((e) => setMsg({ s: 'error', t: e.message })), []);
  useEffect(() => { load(); }, [load]);
  const run = async (fn, ok) => {
    try { const r = await fn(); setMsg({ s: 'success', t: ok }); load(); return r; }
    catch (e) { setMsg({ s: 'error', t: e.message }); return null; }
  };

  const saveModel = async () => {
    const body = { code: dlg.code.trim(), name: dlg.name.trim(), description: dlg.description, active: dlg.active,
      min_confidence: dlg.min_confidence === '' || dlg.min_confidence == null ? null : Number(dlg.min_confidence) };
    if (await run(() => (dlg.id ? api.updateModel(dlg.id, body) : api.createModel(body)), 'Modelo guardado.') !== null) setDlg(null);
  };
  const addLayout = async () => {
    const r = await run(() => api.addLayout(layoutDlg.id, lname, file, true), 'Layout criado. Desenhe as regiões no editor.');
    if (r) { setLayoutDlg(null); setFile(null); onEditLayout(r.id); }
  };
  const replace = async (e) => {
    const f = e.target.files[0]; e.target.value = '';
    if (f) run(() => api.replaceImage(replaceId.current, f, true), 'Imagem de referência substituída.');
  };

  return (
    <Stack spacing={2}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
        <Typography variant="h5" sx={{ fontWeight: 700 }}>Modelos</Typography>
        <Button variant="contained" startIcon={<AddIcon />} onClick={() => setDlg({ ...EMPTY })}>Novo modelo</Button>
      </Box>
      {msg && <Alert severity={msg.s} onClose={() => setMsg(null)}>{msg.t}</Alert>}
      <input ref={replaceInput} type="file" accept="image/*" hidden onChange={replace} />
      {models.map((m) => (
        <Paper key={m.id} sx={{ p: 2, opacity: m.active ? 1 : 0.6 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Typography variant="h6" sx={{ fontWeight: 800, minWidth: 110 }}>{m.code}</Typography>
            <Box sx={{ flex: 1 }}><Typography>{m.name}</Typography><Typography variant="body2" color="text.secondary">{m.description}</Typography></Box>
            {!m.active && <Chip size="small" label="Inativo" />}
            {m.min_confidence != null && <Chip size="small" color="secondary" label={`mín. ${m.min_confidence}%`} />}
            <Button size="small" onClick={() => { setLayoutDlg(m); setLname(`Layout ${m.layouts.length + 1}`); }}>Adicionar layout</Button>
            <IconButton aria-label="Editar modelo" onClick={() => setDlg({ ...m })}><EditIcon /></IconButton>
            <IconButton aria-label="Apagar modelo" onClick={() => window.confirm(`Apagar o modelo ${m.code} e todos os seus layouts?`) && run(() => api.deleteModel(m.id), 'Modelo apagado.')}><DeleteIcon /></IconButton>
          </Box>
          <Stack direction="row" spacing={2} sx={{ mt: 2, flexWrap: 'wrap', gap: 2 }}>
            {m.layouts.map((l) => (
              <Paper key={l.id} variant="outlined" sx={{ p: 1, width: 210, opacity: l.active ? 1 : 0.55 }}>
                <img src={`/api/layouts/${l.id}/image?t=${Date.now()}`} alt={l.name} style={{ width: '100%', borderRadius: 4, background: '#ddd', minHeight: 80 }} />
                <Typography variant="subtitle2">{l.name}</Typography>
                <Typography variant="caption" color="text.secondary">{l.region_count} regiões</Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mt: 0.5 }}>
                  <Button size="small" variant="contained" onClick={() => onEditLayout(l.id)}>Regiões</Button>
                  <Button size="small" onClick={() => { replaceId.current = l.id; replaceInput.current.click(); }}>Imagem</Button>
                  <Button size="small" onClick={() => run(() => api.updateLayout(l.id, { name: l.name, active: !l.active }), 'Layout atualizado.')}>{l.active ? 'Desativar' : 'Ativar'}</Button>
                  <Button size="small" color="error" onClick={() => window.confirm('Apagar este layout?') && run(() => api.deleteLayout(l.id), 'Layout apagado.')}>Apagar</Button>
                </Box>
              </Paper>
            ))}
            {!m.layouts.length && <Typography color="text.secondary">Sem layouts. Adicione um com uma fotografia de referência.</Typography>}
          </Stack>
        </Paper>
      ))}
      {!models.length && <Alert severity="info">Ainda não há modelos. Crie o primeiro (ex.: AM) e adicione um layout.</Alert>}

      <Dialog open={!!dlg} onClose={() => setDlg(null)} fullWidth maxWidth="sm">
        <DialogTitle>{dlg?.id ? 'Editar modelo' : 'Novo modelo'}</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField label="Código (ex.: AN_AP_AS)" value={dlg?.code || ''} onChange={(e) => setDlg({ ...dlg, code: e.target.value })} />
            <TextField label="Nome" value={dlg?.name || ''} onChange={(e) => setDlg({ ...dlg, name: e.target.value })} />
            <TextField label="Descrição" multiline minRows={2} value={dlg?.description || ''} onChange={(e) => setDlg({ ...dlg, description: e.target.value })} />
            <TextField type="number" label="Confiança mínima deste modelo (%) — vazio = usar a global" inputProps={{ min: 0, max: 100, step: 1 }}
              value={dlg?.min_confidence ?? ''} onChange={(e) => setDlg({ ...dlg, min_confidence: e.target.value })} />
            <FormControlLabel control={<Switch checked={!!dlg?.active} onChange={(e) => setDlg({ ...dlg, active: e.target.checked })} />} label="Ativo na identificação" />
          </Stack>
        </DialogContent>
        <DialogActions><Button onClick={() => setDlg(null)}>Cancelar</Button><Button variant="contained" onClick={saveModel}>Guardar</Button></DialogActions>
      </Dialog>

      <Dialog open={!!layoutDlg} onClose={() => setLayoutDlg(null)} fullWidth maxWidth="sm">
        <DialogTitle>Novo layout — {layoutDlg?.code}</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField label="Nome do layout" value={lname} onChange={(e) => setLname(e.target.value)} />
            <Button component="label" variant="outlined">{file ? file.name : 'Escolher fotografia de referência'}
              <input type="file" accept="image/*" hidden onChange={(e) => setFile(e.target.files[0] || null)} /></Button>
            }
              label="Detetar e endireitar a Fuse Box automaticamente" />
          </Stack>
        </DialogContent>
        <DialogActions><Button onClick={() => setLayoutDlg(null)}>Cancelar</Button>
          <Button variant="contained" disabled={!file || !lname.trim()} onClick={addLayout}>Criar layout</Button></DialogActions>
      </Dialog>
    </Stack>
  );
}
