import { useEffect, useState } from 'react';
import { Alert, Box, Button, FormControlLabel, MenuItem, Paper, Slider, Stack, Switch, TextField, Typography } from '@mui/material';
import { api } from '../api.js';

const FIELDS = [
  ['color_tolerance', 'Tolerância de cor', 0, 50, 1, 'Alarga as gamas de cor (H ± valor; S/V ± valor×2,55; distância RGB ± valor×4,4). Aumente com iluminação variável.'],
  ['position_tolerance', 'Tolerância de posição (%)', 0, 20, 0.5, 'Deslocamento máximo de cada região, em % da largura, para compensar pequenos desalinhamentos.'],
  ['rotation_tolerance', 'Tolerância de rotação (°)', 0, 45, 1, 'Ângulos testados à volta do alinhamento automático (±valor). A caixa também é testada rodada 180°.'],
  ['min_confidence', 'Confiança mínima (%)', 0, 100, 1, 'Valor global: abaixo dele o resultado é FAIL (ex.: 80 aceita 80 %). Cada modelo pode ter o seu próprio mínimo em Modelos → editar.'],
  ['min_margin', 'Margem mínima para o 2.º modelo (pontos %)', 0, 100, 1, 'Se o segundo melhor modelo ficar mais perto do que isto, o resultado é ambíguo (FAIL).'],
  ['min_box_area', 'Área mínima da Fuse Box na foto (%)', 1, 90, 1, 'Contornos menores são ignorados na deteção.'],
];

export default function Tolerances() {
  const [v, setV] = useState(null);
  const [msg, setMsg] = useState(null);
  const [colors, setColors] = useState([]);
  useEffect(() => { api.settings().then(setV); api.colors().then(setColors); }, []);
  if (!v) return null;
  const save = async () => {
    try { setV(await api.saveSettings(v)); setMsg({ s: 'success', t: 'Tolerâncias guardadas. Aplicam-se à próxima identificação.' }); }
    catch (e) { setMsg({ s: 'error', t: e.message }); }
  };
  return (
    <Stack spacing={2}>
      <Typography variant="h5" sx={{ fontWeight: 700 }}>Tolerâncias</Typography>
      {msg && <Alert severity={msg.s} onClose={() => setMsg(null)}>{msg.t}</Alert>}
      <Paper sx={{ p: 3 }}>
        <Stack spacing={3}>
          {FIELDS.map(([k, label, min, max, step, help]) => (
            <Box key={k}>
              <Typography sx={{ fontWeight: 600 }}>{label}: {v[k]}</Typography>
              <Stack direction="row" spacing={2} alignItems="center">
                <Slider min={min} max={max} step={step} value={Number(v[k])} onChange={(_, x) => setV({ ...v, [k]: x })} valueLabelDisplay="auto" />
                <TextField type="number" size="small" value={v[k]} sx={{ width: 100 }} inputProps={{ min, max, step }}
                  onChange={(e) => setV({ ...v, [k]: e.target.value === '' ? '' : Math.max(min, Math.min(max, Number(e.target.value))) })} />
              </Stack>
              <Typography variant="body2" color="text.secondary">{help}</Typography>
            </Box>
          ))}
          <Paper variant="outlined" sx={{ p: 2 }}>
            <Typography sx={{ fontWeight: 600, mb: 1 }}>Alinhamento da imagem</Typography>
            <Stack direction="row" spacing={2}>
              <TextField select size="small" label="Método" value={v.align_mode} onChange={(e) => setV({ ...v, align_mode: e.target.value })} sx={{ minWidth: 300 }}>
                <MenuItem value="box">Contorno da caixa (fotografia inteira)</MenuItem>
                <MenuItem value="anchors">Âncoras de cor (recomendado)</MenuItem>
              </TextField>
              {v.align_mode === 'anchors' && (
                <TextField select size="small" label="Cor da âncora" value={v.anchor_color} onChange={(e) => setV({ ...v, anchor_color: e.target.value })} sx={{ minWidth: 180 }}>
                  {colors.map((c) => <MenuItem key={c.name} value={c.name}>{c.name}</MenuItem>)}
                </TextField>
              )}
            </Stack>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
              <b>Âncoras</b>: usa o maior bloco da cor escolhida (ex.: os 2 relés vermelhos, comuns a todos os modelos) para fixar posição, escala e inclinação da Fuse Box, seja qual for o enquadramento da fotografia. Imagem alinhada fixa em 600×800.
              <br /><b>Ao mudar o método, volte a carregar a imagem de referência de cada layout (botão “Imagem”) e confirme as regiões.</b>
            </Typography>
          </Paper>
          <FormControlLabel control={<Switch checked={v.require_box} onChange={(e) => setV({ ...v, require_box: e.target.checked })} />}
            label="Exigir deteção da Fuse Box (sem caixa detetada = FAIL)" />
          <Stack direction="row" spacing={2}>
            <TextField type="number" label="Largura da imagem alinhada (px)" value={v.canvas_width} onChange={(e) => setV({ ...v, canvas_width: e.target.value })} />
            <TextField type="number" label="Altura da imagem alinhada (px)" value={v.canvas_height} onChange={(e) => setV({ ...v, canvas_height: e.target.value })} />
            <TextField type="number" label="Retenção do histórico (dias, 0 = sempre)" value={v.history_retention_days} onChange={(e) => setV({ ...v, history_retention_days: e.target.value })} sx={{ minWidth: 280 }} />
          </Stack>
          <Typography variant="body2" color="text.secondary">Alterar o tamanho da imagem alinhada não invalida as regiões (são guardadas em proporção), mas as imagens de referência existentes mantêm o tamanho com que foram criadas.</Typography>
          <Box><Button variant="contained" onClick={save}>Guardar tolerâncias</Button></Box>
        </Stack>
      </Paper>
    </Stack>
  );
}
