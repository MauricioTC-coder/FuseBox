import { useEffect, useState } from 'react';
import { Alert, Box, Grid, MenuItem, Paper, Stack, TextField, Typography } from '@mui/material';
import { api } from '../api.js';

const Kpi = ({ label, value, color }) => (
  <Paper sx={{ p: 2, borderTop: `6px solid ${color || '#2f3b47'}` }}>
    <Typography color="text.secondary">{label}</Typography>
    <Typography sx={{ fontSize: 44, fontWeight: 800, fontVariantNumeric: 'tabular-nums' }}>{value}</Typography>
  </Paper>
);

const Bars = ({ items, label, value, max }) => (
  <Stack spacing={1}>
    {items.map((i) => (
      <Box key={label(i)} sx={{ display: 'grid', gridTemplateColumns: '90px 1fr 48px', alignItems: 'center', gap: 1 }}>
        <Typography variant="body2" noWrap>{label(i)}</Typography>
        <Box sx={{ bgcolor: '#e3e6e1', height: 18, borderRadius: 1 }}>
          <Box sx={{ width: `${(100 * value(i)) / max}%`, height: '100%', bgcolor: '#f2b705', borderRadius: 1 }} />
        </Box>
        <Typography variant="body2" align="right" sx={{ fontVariantNumeric: 'tabular-nums' }}>{value(i)}</Typography>
      </Box>
    ))}
    {!items.length && <Typography color="text.secondary">Sem dados.</Typography>}
  </Stack>
);

export default function Dashboard() {
  const [days, setDays] = useState(7);
  const [d, setD] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    const load = () => api.dashboard(days).then(setD).catch((e) => setError(e.message));
    load();
    const t = setInterval(load, 15000); // atualização automática
    return () => clearInterval(t);
  }, [days]);

  if (error) return <Alert severity="error">{error}</Alert>;
  if (!d) return null;
  const maxF = Math.max(1, ...d.frequency.map((x) => x.n));
  const maxD = Math.max(1, ...d.daily.map((x) => x.total));
  const maxH = Math.max(1, ...d.hourly.map((x) => x.total));
  return (
    <Stack spacing={3}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h5" sx={{ fontWeight: 700 }}>Dashboard</Typography>
        <TextField select size="small" label="Período" value={days} onChange={(e) => setDays(+e.target.value)}>
          <MenuItem value={1}>Hoje</MenuItem><MenuItem value={7}>7 dias</MenuItem><MenuItem value={30}>30 dias</MenuItem>
        </TextField>
      </Box>
      <Grid container spacing={2}>
        <Grid item xs={6} md={3}><Kpi label="Produção de hoje" value={d.today.total} /></Grid>
        <Grid item xs={6} md={3}><Kpi label="Acertos (PASS)" value={d.today.pass} color="#1b8a3a" /></Grid>
        <Grid item xs={6} md={3}><Kpi label="Falhas (FAIL)" value={d.today.fail} color="#c62828" /></Grid>
        <Grid item xs={6} md={3}><Kpi label="Taxa de acerto" value={d.today.pass_rate == null ? '—' : `${d.today.pass_rate}%`} /></Grid>
      </Grid>
      <Grid container spacing={2}>
        <Grid item xs={12} md={4}><Paper sx={{ p: 2 }}><Typography variant="h6" sx={{ mb: 2 }}>Modelos mais frequentes</Typography>
          <Bars items={d.frequency} label={(i) => i.model_code} value={(i) => i.n} max={maxF} /></Paper></Grid>
        <Grid item xs={12} md={4}><Paper sx={{ p: 2 }}><Typography variant="h6" sx={{ mb: 2 }}>Produção por dia</Typography>
          <Bars items={d.daily} label={(i) => i.day} value={(i) => i.total} max={maxD} /></Paper></Grid>
        <Grid item xs={12} md={4}><Paper sx={{ p: 2 }}><Typography variant="h6" sx={{ mb: 2 }}>Hoje, por hora</Typography>
          <Bars items={d.hourly} label={(i) => `${i.hour}h`} value={(i) => i.total} max={maxH} /></Paper></Grid>
      </Grid>
    </Stack>
  );
}
