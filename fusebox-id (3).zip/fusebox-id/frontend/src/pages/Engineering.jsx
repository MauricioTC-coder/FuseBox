import { useEffect, useState } from 'react';
import { Alert, Box, Button, Paper, Stack, Tab, Tabs, TextField, Typography } from '@mui/material';
import { api, getToken, setToken } from '../api.js';
import Models from '../eng/Models.jsx';
import Editor from '../eng/Editor.jsx';
import Colors from '../eng/Colors.jsx';
import Tolerances from '../eng/Tolerances.jsx';
import Admin from '../eng/Admin.jsx';

// Área protegida por password. O token expira (por defeito 1 h) e é pedido de novo.
export default function Engineering() {
  const [authed, setAuthed] = useState(!!getToken());
  const [pw, setPw] = useState('');
  const [error, setError] = useState('');
  const [tab, setTab] = useState(0);
  const [layoutId, setLayoutId] = useState(null);

  useEffect(() => {
    const out = () => setAuthed(false);
    window.addEventListener('eng-logout', out);
    if (getToken()) api.checkAuth().catch(() => {});
    return () => window.removeEventListener('eng-logout', out);
  }, []);

  const login = async (e) => {
    e.preventDefault();
    try { const r = await api.login(pw); setToken(r.token); setAuthed(true); setPw(''); setError(''); }
    catch (err) { setError(err.message); }
  };

  if (!authed) {
    return (
      <Paper component="form" onSubmit={login} sx={{ p: 4, maxWidth: 420, mx: 'auto', mt: 6 }}>
        <Typography variant="h5" sx={{ fontWeight: 700, mb: 2 }}>Modo Engenharia</Typography>
        <Stack spacing={2}>
          <TextField type="password" label="Password" autoFocus value={pw} onChange={(e) => setPw(e.target.value)} />
          {error && <Alert severity="error">{error}</Alert>}
          <Button type="submit" variant="contained" size="large">Entrar</Button>
        </Stack>
      </Paper>
    );
  }

  const goEditor = (id) => { setLayoutId(id); setTab(1); };
  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Tabs value={tab} onChange={(_, v) => setTab(v)} variant="scrollable">
          <Tab label="Modelos" /><Tab label="Editor de regiões" /><Tab label="Cores" /><Tab label="Tolerâncias" /><Tab label="Sistema" />
        </Tabs>
        <Button onClick={() => { setToken(null); setAuthed(false); }}>Terminar sessão</Button>
      </Box>
      {tab === 0 && <Models onEditLayout={goEditor} />}
      {tab === 1 && <Editor initialLayoutId={layoutId} />}
      {tab === 2 && <Colors />}
      {tab === 3 && <Tolerances />}
      {tab === 4 && <Admin />}
    </Box>
  );
}
