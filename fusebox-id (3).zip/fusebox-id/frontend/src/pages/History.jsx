import { useCallback, useEffect, useState } from 'react';
import { Alert, Button, Chip, Dialog, DialogContent, DialogTitle, MenuItem, Paper, Stack, Table, TableBody, TableCell,
  TableHead, TablePagination, TableRow, TextField, Typography } from '@mui/material';
import { api } from '../api.js';
import ResultView from '../components/ResultView.jsx';

export default function History() {
  const [f, setF] = useState({ q: '', status: '', date_from: '', date_to: '' });
  const [page, setPage] = useState(0);
  const [rows, setRows] = useState({ total: 0, items: [] });
  const [error, setError] = useState('');
  const [detail, setDetail] = useState(null);
  const size = 25;

  const load = useCallback(async (p = page, filt = f) => {
    try { setError(''); setRows(await api.history({ ...filt, limit: size, offset: p * size })); }
    catch (e) { setError(e.message); }
  }, [page, f]);
  useEffect(() => { load(page); /* eslint-disable-next-line */ }, [page]);

  const open = async (id) => {
    const h = await api.historyItem(id);
    setDetail({ ...h.details, id: h.id, status: h.status, model_code: h.model_code, model_name: h.details.ranking?.[0]?.model_name || '',
      confidence: h.score, timestamp: h.ts, operator: h.operator });
  };
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const search = () => { setPage(0); load(0, f); };

  return (
    <Stack spacing={2}>
      <Paper sx={{ p: 2 }}>
        <Typography variant="h5" sx={{ fontWeight: 700, mb: 2 }}>Histórico</Typography>
        <Stack direction={{ xs: 'column', md: 'row' }} spacing={2}>
          <TextField label="Modelo ou operador" value={f.q} onChange={set('q')} onKeyDown={(e) => e.key === 'Enter' && search()} />
          <TextField select label="Estado" value={f.status} onChange={set('status')} sx={{ minWidth: 140 }}>
            <MenuItem value="">Todos</MenuItem><MenuItem value="PASS">PASS</MenuItem><MenuItem value="FAIL">FAIL</MenuItem>
          </TextField>
          <TextField type="date" label="De" InputLabelProps={{ shrink: true }} value={f.date_from} onChange={set('date_from')} />
          <TextField type="date" label="Até" InputLabelProps={{ shrink: true }} value={f.date_to} onChange={set('date_to')} />
          <Button variant="contained" onClick={search}>Pesquisar</Button>
        </Stack>
      </Paper>
      {error && <Alert severity="error">{error}</Alert>}
      <Paper>
        <Table size="small">
          <TableHead><TableRow><TableCell>Data / hora</TableCell><TableCell>Operador</TableCell><TableCell>Modelo</TableCell>
            <TableCell align="right">Score</TableCell><TableCell>Estado</TableCell></TableRow></TableHead>
          <TableBody>
            {rows.items.map((r) => (
              <TableRow key={r.id} hover sx={{ cursor: 'pointer' }} onClick={() => open(r.id)}>
                <TableCell>{r.ts}</TableCell><TableCell>{r.operator}</TableCell><TableCell>{r.model_code}</TableCell>
                <TableCell align="right">{r.score?.toFixed(1)}%</TableCell>
                <TableCell><Chip size="small" label={r.status} color={r.status === 'PASS' ? 'success' : 'error'} /></TableCell>
              </TableRow>
            ))}
            {!rows.items.length && <TableRow><TableCell colSpan={5} align="center">Sem registos para estes filtros.</TableCell></TableRow>}
          </TableBody>
        </Table>
        <TablePagination component="div" count={rows.total} page={page} rowsPerPage={size} rowsPerPageOptions={[size]}
          onPageChange={(_, p) => setPage(p)} />
      </Paper>
      <Dialog open={!!detail} onClose={() => setDetail(null)} maxWidth="lg" fullWidth>
        <DialogTitle>Registo #{detail?.id} — {detail?.timestamp} — {detail?.operator}</DialogTitle>
        <DialogContent>{detail && <ResultView result={{ ...detail, reasons: detail.reasons || [], warnings: detail.warnings || [], ranking: detail.ranking || [], regions: detail.regions || [] }} />}</DialogContent>
      </Dialog>
    </Stack>
  );
}
