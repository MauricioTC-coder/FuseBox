import { useRef, useState } from 'react';
import { Alert, Box, Button, CircularProgress, Paper, Stack, TextField, Typography } from '@mui/material';
import CameraAltIcon from '@mui/icons-material/CameraAlt';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import VideocamIcon from '@mui/icons-material/Videocam';
import { api } from '../api.js';
import Webcam from '../components/Webcam.jsx';
import ResultView from '../components/ResultView.jsx';

export default function Identify() {
  const [operator, setOperator] = useState(localStorage.getItem('operator') || '');
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [cam, setCam] = useState(false);
  const camInput = useRef(null);
  const fileInput = useRef(null);

  const submit = async (file) => {
    if (!file) return;
    if (!operator.trim()) { setError('Indique o operador antes de capturar.'); return; }
    localStorage.setItem('operator', operator.trim());
    setBusy(true); setError(''); setResult(null);
    try { setResult(await api.identify(file, operator.trim(), false)); }
    catch (e) { setError(e.message); }
    finally { setBusy(false); }
  };
  const pick = (e) => { submit(e.target.files[0]); e.target.value = ''; };

  return (
    <Stack spacing={3}>
      <Paper sx={{ p: 3 }}>
        <Typography variant="h5" sx={{ fontWeight: 700, mb: 2 }}>Identificar Fuse Box</Typography>
        <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} alignItems={{ md: 'center' }}>
          <TextField label="Operador" value={operator} onChange={(e) => setOperator(e.target.value)} sx={{ minWidth: 220 }} />
          <input ref={camInput} type="file" accept="image/*" capture="environment" hidden onChange={pick} />
          <input ref={fileInput} type="file" accept="image/*" hidden onChange={pick} />
          <Button size="large" variant="contained" color="secondary" startIcon={<CameraAltIcon />} disabled={busy}
            onClick={() => camInput.current.click()} sx={{ py: 1.6, color: '#1c2024' }}>Tirar fotografia</Button>
          <Button size="large" variant="outlined" startIcon={<VideocamIcon />} disabled={busy} onClick={() => setCam(true)}>Webcam</Button>
          <Button size="large" variant="outlined" startIcon={<UploadFileIcon />} disabled={busy} onClick={() => fileInput.current.click()}>Escolher ficheiro</Button>
          {busy && <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}><CircularProgress size={24} /> A analisar…</Box>}
        </Stack>
        {error && <Alert severity="error" sx={{ mt: 2 }}>{error}</Alert>}
      </Paper>
      {result && <ResultView result={result} />}
      <Webcam open={cam} onClose={() => setCam(false)} onCapture={submit} />
    </Stack>
  );
}
