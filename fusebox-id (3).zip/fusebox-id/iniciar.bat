@echo off
setlocal
cd /d "%~dp0"
title FuseBox ID

set "PY="
py -3 --version >nul 2>&1
if not errorlevel 1 set "PY=py -3"
if not defined PY (
  python --version >nul 2>&1
  if not errorlevel 1 set "PY=python"
)
if not defined PY goto instalar_python

%PY% run.py --open %*
if errorlevel 1 (
  echo.
  echo O FuseBox ID terminou com erro. Leia as mensagens acima.
  pause
)
exit /b

:instalar_python
echo Python nao encontrado. A tentar instalar o Python 3.12 com o winget...
where winget >nul 2>&1
if errorlevel 1 goto sem_winget
winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
echo.
echo Python instalado. FECHE esta janela e execute iniciar.bat outra vez.
pause
exit /b 0

:sem_winget
echo.
echo Instale o Python 3.12 em https://www.python.org/downloads/
echo (marque a opcao "Add python.exe to PATH") e execute iniciar.bat de novo.
pause
exit /b 1
