#!/usr/bin/env bash
# Arranque no Ubuntu/Debian (também por duplo clique): instala o que faltar, cria o ambiente e inicia.
cd "$(dirname "$0")" || exit 1
SELF="$(readlink -f "$0")"

# Aberto sem terminal (duplo clique no gestor de ficheiros)? Reabre dentro de um terminal.
if [ ! -t 1 ] && [ -z "$FUSEBOX_IN_TERM" ]; then
  export FUSEBOX_IN_TERM=1
  CMD="bash \"$SELF\"; echo; read -r -p 'Prima Enter para fechar... ' _"
  for t in gnome-terminal mate-terminal xfce4-terminal konsole x-terminal-emulator xterm; do
    command -v "$t" >/dev/null 2>&1 || continue
    case "$t" in
      gnome-terminal|mate-terminal) exec "$t" -- bash -c "$CMD" ;;
      xfce4-terminal) exec "$t" -e "bash -c '$CMD'" ;;
      *) exec "$t" -e bash -c "$CMD" ;;
    esac
  done
fi

SUDO=""; [ "$(id -u)" -ne 0 ] && SUDO="sudo"
if ! command -v python3 >/dev/null 2>&1; then
  echo "[FuseBox] A instalar o Python 3 (pode pedir a palavra-passe)..."
  $SUDO apt-get update && $SUDO apt-get install -y python3 python3-venv python3-pip || exit 1
fi
tmp="$(mktemp -d)"
if ! python3 -m venv "$tmp/v" >/dev/null 2>&1; then
  echo "[FuseBox] A instalar python3-venv (pode pedir a palavra-passe)..."
  $SUDO apt-get update && $SUDO apt-get install -y python3-venv python3-pip || exit 1
fi
rm -rf "$tmp"

OPEN=""; [ -n "$DISPLAY$WAYLAND_DISPLAY" ] && OPEN="--open"   # abre o browser se houver ambiente gráfico
python3 run.py $OPEN "$@"
rc=$?
if [ $rc -ne 0 ] && [ -t 0 ]; then read -r -p "O FuseBox ID terminou com erro (código $rc). Prima Enter... " _; fi
exit $rc
