@echo off
rem Cria uma tarefa agendada para arrancar o FuseBox ID quando iniciar sessao no Windows.
rem Para remover:  schtasks /Delete /TN "FuseBox ID" /F
cd /d "%~dp0"
schtasks /Create /TN "FuseBox ID" /TR "\"%~dp0iniciar.bat\"" /SC ONLOGON /RL LIMITED /F
if errorlevel 1 (echo Falhou. Execute como Administrador.) else (echo Tarefa criada: o FuseBox ID arranca ao iniciar sessao.)
pause
