#!/usr/bin/env bash
# Cria um ícone "FuseBox ID" no ambiente de trabalho e no menu de aplicações (já marcado como confiável).
cd "$(dirname "$0")" || exit 1
ROOT="$(pwd)"
chmod +x iniciar.sh instalar_servico.sh run.py "Iniciar FuseBox ID.desktop" 2>/dev/null

make_launcher() {
  cat > "$1" <<DESK
[Desktop Entry]
Type=Application
Name=FuseBox ID
Comment=Arranca o FuseBox ID
Exec=bash -c 'cd "$ROOT" && ./iniciar.sh'
Path=$ROOT
Terminal=true
Icon=utilities-terminal
Categories=Utility;
DESK
  chmod +x "$1"
  command -v gio >/dev/null 2>&1 && gio set "$1" metadata::trusted true 2>/dev/null
}

mkdir -p "$HOME/.local/share/applications"
make_launcher "$HOME/.local/share/applications/fusebox-id.desktop"
DESK="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Desktop")"
if [ -d "$DESK" ]; then make_launcher "$DESK/FuseBox ID.desktop"; echo "Ícone criado em: $DESK/FuseBox ID.desktop"; fi
echo "Pronto. Agora basta duplo clique em 'FuseBox ID' (ambiente de trabalho ou menu de aplicações)."
