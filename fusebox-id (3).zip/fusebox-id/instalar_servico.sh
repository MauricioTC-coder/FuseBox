#!/usr/bin/env bash
# Ubuntu: instala o FuseBox ID como serviço (arranca com o servidor e reinicia se falhar).
set -e
[ "$(id -u)" -eq 0 ] || exec sudo "$0" "$@"
ROOT="$(cd "$(dirname "$0")" && pwd)"
RUN_USER="${SUDO_USER:-root}"
sudo -u "$RUN_USER" bash "$ROOT/iniciar.sh" --install-only
cat > /etc/systemd/system/fusebox.service <<UNIT
[Unit]
Description=FuseBox ID
After=network.target

[Service]
User=$RUN_USER
WorkingDirectory=$ROOT
ExecStart=$ROOT/.venv/bin/python $ROOT/run.py
Restart=always

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now fusebox
echo "Serviço ativo. Estado: systemctl status fusebox   |   Logs: journalctl -u fusebox -f"
