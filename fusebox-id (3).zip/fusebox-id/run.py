#!/usr/bin/env python3
"""
Lançador multiplataforma (Windows / Ubuntu) do FuseBox ID.

Na 1.ª execução cria o ambiente virtual (.venv), instala as dependências e arranca o servidor.
Nas seguintes só arranca (reinstala sozinho se requirements.txt mudar).

  python run.py                 arranca (http://<ip>:8080)
  python run.py --install-only  só prepara o ambiente
  python run.py --port 9000     outra porta
  python run.py --open          abre o browser
"""
import argparse
import hashlib
import os
import shutil
import socket
import subprocess
import sys
import threading
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BACKEND = ROOT / "backend"
VENV = ROOT / ".venv"
VPY = VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
REQ = BACKEND / "requirements.txt"


def log(msg: str):
    print(f"[FuseBox] {msg}", flush=True)


def in_our_venv() -> bool:
    return sys.prefix != sys.base_prefix and Path(sys.prefix).resolve() == VENV.resolve()


def ensure_env():
    """Cria .venv e instala dependências (idempotente)."""
    if sys.version_info < (3, 9):
        sys.exit("É necessário Python 3.9 ou superior (recomendado 3.10–3.12).")
    pip_ok = VPY.exists() and subprocess.call([str(VPY), "-m", "pip", "--version"],
                                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) == 0
    if not pip_ok:
        shutil.rmtree(VENV, ignore_errors=True)  # venv partido (ex.: falta python3-venv)
        log("A criar o ambiente virtual (.venv)...")
        r = subprocess.call([sys.executable, "-m", "venv", str(VENV)])
        if r != 0 or not VPY.exists():
            shutil.rmtree(VENV, ignore_errors=True)
            sys.exit("Falhou a criação do ambiente virtual.\n"
                     "Ubuntu/Debian: sudo apt install python3-venv python3-pip   e execute de novo.")
    digest = hashlib.sha256(REQ.read_bytes()).hexdigest()
    stamp = VENV / ".req_hash"
    if not stamp.exists() or stamp.read_text() != digest:
        log("A instalar dependências (só acontece na 1.ª vez; pode demorar alguns minutos)...")
        subprocess.call([str(VPY), "-m", "pip", "install", "--quiet", "--upgrade", "pip"])
        if subprocess.call([str(VPY), "-m", "pip", "install", "-r", str(REQ)]) != 0:
            sys.exit("Falhou a instalação das dependências. Verifique a ligação à Internet e tente de novo.")
        stamp.write_text(digest)
        log("Dependências instaladas.")


def load_env():
    """Lê o .env (cria-o a partir do .env.example se não existir). Variáveis já definidas têm prioridade."""
    env, example = ROOT / ".env", ROOT / ".env.example"
    if not env.exists() and example.exists():
        shutil.copy(example, env)
    if env.exists():
        for line in env.read_text(encoding="utf-8-sig").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


def lan_ip() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--install-only", action="store_true")
    ap.add_argument("--host")
    ap.add_argument("--port", type=int)
    ap.add_argument("--open", action="store_true", help="abrir o browser")
    args = ap.parse_args()

    if not in_our_venv():
        ensure_env()
        if args.install_only:
            log("Ambiente pronto.")
            return 0
        return subprocess.call([str(VPY), str(Path(__file__).resolve()), *sys.argv[1:]])

    load_env()
    os.environ.setdefault("FUSEBOX_DATA_DIR", str(ROOT / "data"))
    host = args.host or os.environ.get("FUSEBOX_HOST", "0.0.0.0")
    port = args.port or int(os.environ.get("FUSEBOX_PORT", "8080"))
    if not (BACKEND / "web" / "index.html").exists():
        log("AVISO: interface compilada não encontrada em backend/web (só a API ficará disponível).")
    os.chdir(BACKEND)
    sys.path.insert(0, str(BACKEND))

    log(f"A iniciar em  http://localhost:{port}   (rede: http://{lan_ip()}:{port})")
    log(f"Dados em: {os.environ['FUSEBOX_DATA_DIR']}   |   Para parar: Ctrl+C ou feche esta janela")
    if args.open:
        threading.Timer(2.5, lambda: webbrowser.open(f"http://localhost:{port}")).start()
    import uvicorn
    uvicorn.run("app.main:app", host=host, port=port, workers=int(os.environ.get("FUSEBOX_WORKERS", "1")),
                log_level="info")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(0)
